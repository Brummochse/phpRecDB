<?php
include_once dirname(__FILE__) . "/../constants.php";
include_once Constants::getClassFolder()."SignatureCreator.php";
include_once Constants::getClassFolder()."SignatureSettings.php";

$sigConfig=new SignatureSettings();
$sigConfig->load();
$signatureCreator=new SignatureCreator($sigConfig);
$signatureImage=$signatureCreator->getImage();

if ($signatureImage!=null) {
    Header("Expires: -1");
    Header("Cache-Control: post-check=0, pre-check=0");
    Header("Pragma: no-cache");
    Header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
    Header("Content-type: image/jpeg");
    ImageJPEG($signatureImage);
    ImageDestroy($signatureImage);
}
?> 