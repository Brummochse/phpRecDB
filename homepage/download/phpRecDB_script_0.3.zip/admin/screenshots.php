<?php
include_once "../constants.php";
include_once Constants::getSettingsFolder() . "dbConnection.php";
include_once "functions/screenshotDb.php";
include_once Constants::getFunctionsFolder() . "function.getConcertInfo.php";
include_once Constants::getLibsFolder() . 'Smarty/Smarty.class.php';
include_once (Constants::getFunctionsFolder() . "function.getScreenshotsData.php");
include_once (Constants::getClassFolder() . "Linky.php");
include_once (Constants::getClassFolder() . "ScreenshotUploader.php");
include_once Constants::getClassFolder() . "Helper.php";

class ContentPage extends ContentPageSmarty {

    public function getPageTemplateFileName() {
        return "screenshots.tpl";
    }

    public function execute($smarty,$linky) {
        dbConnect();

        $recordingId= Helper::getAsInt('id');
        if ($recordingId != null) {

            if (isset ($_POST['sent'])) {
                $uploader = new ScreenshotUploader();
                $uploader->uploadFile("screenshot",$recordingId);

                addNewScreenshot($recordingId, $uploader->getNewImagefilename(), $uploader->getNewThumbnailFilename());
            }

            if (isset ($_GET['screenshotId']) && isset ($_GET['action'])) {
                if ($_GET['action'] == "1") {
                    deleteScreenshot($_GET['screenshotId'], "../screenshots/");
                }
                if ($_GET['action'] == "2") {
                    orderBackward($_GET['screenshotId']);
                }
                if ($_GET['action'] == "3") {
                    orderForward($_GET['screenshotId']);
                }
            }

            getScreenshotsData($recordingId, "../screenshots/", $smarty, true);
            getConcertInfo($recordingId, true, $smarty);

            $linky = new Linky(Constants::getParamAdminMenuIndex());
            $smarty->assign('editRecordLink', $linky->encryptName('edit Record', array (
                    'id' => $recordingId
            )));

            $smarty->assign("relativeTemplatesPath", getRelativePathTo(Constants::getTemplateFolder()));
        }
    }
}
?>

