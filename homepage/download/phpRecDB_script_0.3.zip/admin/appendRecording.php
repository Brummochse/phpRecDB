<?php
include_once "functions/insertConcert.php";
include_once "functions/cleanUpDb.php";
include_once Constants::getClassFolder()."SignatureCreator.php";

class ContentPage extends ContentPageSmarty {


    public function getPageTemplateFileName() {
        return "recordAdded.tpl";
    }

    public function execute($smarty,$linky) {
        session_start();

        $selectedShow = $_POST['select'];

        $id_artist = $_SESSION['id_artist'];
        $id_country = $_SESSION['id_country'];
        $id_city = $_SESSION['id_city'];
        $id_venue = $_SESSION['id_venue'];
        $miscBoolean = $_SESSION['miscBoolean'];
        $c_date = $_SESSION['c_date'];
        $c_supplement = $_SESSION['c_supplement'];
        $c_videoOrAudio = $_SESSION['c_videoOrAudio'];

        $c_concertId = $_SESSION['c_concertId'];
        $c_recordingId = $_SESSION['c_recordingId'];
        $c_morerecords = $_SESSION['c_morerecords'];

        $newRecord = empty ($c_recordingId);
        $editRecord = !$newRecord;
        $editAllRecords = $c_morerecords == 'all';
        $editOnlyThisRecord = !$editAllRecords;

        if (empty ($selectedShow))
            throw new Exception('no artist');

        if ($selectedShow == 'new') {
            $concertId = insertConcertAndGetId($id_artist, $c_date, $id_country, $id_city, $id_venue, $c_supplement, $miscBoolean, $c_videoOrAudio);
            $smarty->assign('concertId', $concertId);
        } else {
            $concertId = $selectedShow;
        }
        if ($editRecord) {
            //change concertid in record
            if ($editOnlyThisRecord) {
                changeConcertIdInRecord($c_recordingId, $concertId);
            }
            if ($editAllRecords) {
                $recordsSql = "SELECT id FROM `recordings` WHERE concerts_id=$c_concertId";
                $records = mysql_query($recordsSql) or die("MySQL-Error: " . mysql_error());
                while ($record = mysql_fetch_row($records)) {
                    $oldRecordId = $record[0];
                    changeConcertIdInRecord($oldRecordId, $concertId);
                }
            }
        }
        if ($newRecord) {
            $recordingId = createRecordAndGetId($concertId);

            if ($c_videoOrAudio == 'video') {
                createVideoAndGetId($recordingId);
            } else
            if ($c_videoOrAudio == 'audio') {
                createAudioAndGetId($recordingId);
            } else
                throw new Exception('no video/audio-selection');


            $smarty->assign('audioId', $audioId);
            $smarty->assign('videoId', $videoId);
            $smarty->assign('recordingId', $recordingId);

            $smarty->assign('c_videoOrAudio', $c_videoOrAudio);
            $smarty->assign('editRecordLink', $editRecordLink);
        }

        deleteAllUnusedDbEntrys();
        SignatureCreator::updateSignature();
    }
}
?>
