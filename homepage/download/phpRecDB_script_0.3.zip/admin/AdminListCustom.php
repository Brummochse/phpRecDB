<?php
include_once "../constants.php";
include_once Constants :: getClassFolder() . "AdminList.php";
include_once Constants :: getClassFolder() . "CustomListData.php";
include_once Constants :: getClassFolder() . "Linky.php";
include_once Constants :: getClassFolder() . "SublistMananger.php";
include_once Constants :: getClassFolder() . "StateMsgHandler.php";
include_once Constants :: getLibsFolder() . 'Smarty/Smarty.class.php';
include_once Constants :: getFunctionsFolder() . 'function.getRelativePathTo.php';

class AdminListCustom extends ContentPageSmarty {

    private $bootlegType = "";

    public function __construct($bootlegType) {
        $this->bootlegType=$bootlegType;
    }

    public function getPageTemplateFileName() {
        return "adminList.tpl";
    }

    public function execute($smarty,$linky) {

        $sublistMananger = new SublistMananger();

        $sent = $_POST['sent']; //Weichensteller

        if ($sent == 'yes') {
            $chkRecIds = $_POST['chkRecId']; //Inhalt der Checkboxen
            $listId = $_POST['sublist_id'];

            if (count($chkRecIds) > 0) {
                
                $sublistMananger->moveToSubList($chkRecIds, $listId);

                $msg = "added shows with id:" . implode($chkRecIds, ", ") . " to sublist: " .$sublistMananger->getListNameById($listId);
                $stateMsgHandler = StateMsgHandler :: getInstance();
                $stateMsgHandler->addStateMsg($msg);
            }
        }

        $smarty->assign('sublists', $sublistMananger->getLists());
        $smarty->assign("relativeTemplatesPath", getRelativePathTo(Constants :: getTemplateFolder()));

        $data = new CustomListData($this->bootlegType);
        $adminList = new AdminList($data);
        $adminList->getList($smarty);
    }


}
?>

