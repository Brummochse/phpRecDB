<?php
define("FORWARD", 1);
define("BACKWARD", 2);

include_once dirname(__FILE__) . "/../../constants.php";
include_once Constants :: getClassFolder() . "StateMsgHandler.php";

function addNewScreenshot($recordingId, $newImagefilename, $newThumbnailFilename) {
    $newImagefilename = mysql_real_escape_string($newImagefilename);
    $newThumbnailFilename = mysql_real_escape_string($newThumbnailFilename);

    $orderId = getLastOrderId($recordingId);
    $orderId++; //next order_id = last order_id + 1

    $sqlInsert = "INSERT INTO screenshot (video_recordings_id,screenshot_filename,thumbnail,order_id) VALUES (" . $recordingId . ",'" . $newImagefilename . "','" . $newThumbnailFilename . "','" . $orderId . "');";
    mysql_query($sqlInsert) or die("MySQL-Error: " . mysql_error());
}

function getLastOrderId($recordingId) {
    $row = mysql_fetch_array(mysql_query("SELECT max(order_id) as max_order_id FROM screenshot WHERE video_recordings_id=$recordingId"));
    $nextOrderId = $row['max_order_id'];
    if (empty ($nextOrderId)) {
        return 0;
    } else {
        return $nextOrderId;
    }
}

function deleteScreenshot($screenshotId, $screenshotFolder) {
    $row = mysql_fetch_array(mysql_query("SELECT * FROM `screenshot` WHERE `id` = $screenshotId "));

    $screenshotFile = stripslashes($row['screenshot_filename']);
    $thumbnailFile = stripslashes($row['thumbnail']);

    if ((!empty ($screenshotFile)) && (!empty ($thumbnailFile))) {
        if (file_exists($screenshotFolder . $screenshotFile)) {
            unlink($screenshotFolder . $screenshotFile);
        }
        if (file_exists($screenshotFolder . $thumbnailFile)) {
            unlink($screenshotFolder . $thumbnailFile);
        }
    }
    mysql_query("DELETE FROM `screenshot` WHERE id=$screenshotId") or die("MySQL-Error: " . mysql_error());
}



function orderForward($screenshotId) {
    order($screenshotId, FORWARD);
}
function orderBackward($screenshotId) {
    order($screenshotId, BACKWARD);
}

function order($screenshotId, $direction) {

    $row = mysql_fetch_array(mysql_query("SELECT * FROM screenshot WHERE id=$screenshotId"));
    $video_id = $row['video_recordings_id'];
    $order_id = $row['order_id'];

    if ($direction == FORWARD) {
        $row = mysql_fetch_array(mysql_query(" SELECT id,order_id" .
                " FROM screenshot" .
                " WHERE order_id = (" .
                " SELECT MIN( order_id )" .
                " FROM screenshot" .
                " WHERE order_id >" . $order_id .
                " AND video_recordings_id =" . $video_id . " )" .
                " AND video_recordings_id =" . $video_id));
        $nextScreenshotId = $row['id'];
        $nextOrderId = $row['order_id'];
    } else { //$direction==BACKWARD
        $row = mysql_fetch_array(mysql_query(" SELECT id,order_id" .
                " FROM screenshot" .
                " WHERE order_id = (" .
                " SELECT MAX( order_id )" .
                " FROM screenshot" .
                " WHERE order_id <" . $order_id .
                " AND video_recordings_id =" . $video_id . " )" .
                " AND video_recordings_id =" . $video_id));
        $nextScreenshotId = $row['id'];
        $nextOrderId = $row['order_id'];
    }

    $stateMsgHandler=StateMsgHandler::getInstance();

    if (!empty ($nextScreenshotId)) {
        changeOrderInDb($screenshotId, $nextScreenshotId, $order_id, $nextOrderId);
        $stateMsgHandler->addStateMsg("ordering successfull");
    } else {
        $stateMsgHandler->addStateMsg("error ordering");
    }
}

function changeOrderInDb($screenshotId1, $screenshotId2, $orderId1, $orderId2) {
    $sqlUpdate1 = "UPDATE screenshot SET order_id=" . $orderId1 . " where id=" . $screenshotId2;
    mysql_query($sqlUpdate1) or die("MySQL-Error: " . mysql_error());

    $sqlUpdate2 = "UPDATE screenshot SET order_id=" . $orderId2 . " where id=" . $screenshotId1;
    mysql_query($sqlUpdate2) or die("MySQL-Error: " . mysql_error());
}
?>
