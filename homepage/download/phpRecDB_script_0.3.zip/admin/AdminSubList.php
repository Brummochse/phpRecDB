<?php
include_once "../constants.php";
include_once Constants :: getClassFolder() . "AdminList.php";
include_once Constants :: getClassFolder() . "SubListData.php";
include_once Constants :: getClassFolder() . "Linky.php";
include_once Constants :: getClassFolder() . "SublistMananger.php";
include_once Constants :: getClassFolder() . "StateMsgHandler.php";
include_once Constants :: getLibsFolder() . 'Smarty/Smarty.class.php';
include_once Constants :: getFunctionsFolder() . 'function.getRelativePathTo.php';

class ContentPage extends ContentPageSmarty {

    public function getPageTemplateFileName() {
        return "adminSubList.tpl";
    }

    public function execute($smarty,$linky) {
        $decryptedPageName = $linky->decryptName();

        $sublistMananger = new SublistMananger();
        $subListId = $sublistMananger->getListIdByName($decryptedPageName);

        $sent = $_POST['sent']; //Weichensteller

        if ($sent == 'yes') {
            $chkRecIds = $_POST['chkRecId']; //Inhalt der Checkboxen

            if (count($chkRecIds) > 0) {
                $sublistMananger->removeFromSubList($chkRecIds, $subListId);

                $msg = "shows with id:" . implode($chkRecIds, ", ") . " removed from sublist:" . $sublistMananger->getListNameById($subListId);
                $stateMsgHandler = StateMsgHandler :: getInstance();
                $stateMsgHandler->addStateMsg($msg);
            }
        }

        $smarty->assign("relativeTemplatesPath", getRelativePathTo(Constants :: getTemplateFolder()));

        $data = new SubListData(VIDEO_AND_AUDIO, $subListId);
        $adminList = new AdminList($data);
        $adminList->getList($smarty);
    }
}
?>



