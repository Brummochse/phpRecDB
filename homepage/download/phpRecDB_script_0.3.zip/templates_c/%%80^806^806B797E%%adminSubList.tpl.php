<?php /* Smarty version 2.6.26, created on 2010-05-24 23:13:25
         compiled from admin/adminSubList.tpl */ ?>
<script type="text/javascript" src="<?php echo $this->_tpl_vars['relativeTemplatesPath']; ?>
admin/adminList.js"></script> 
<br>
<link rel="stylesheet" type="text/css" href="<?php echo $this->_tpl_vars['relativeTemplatesPath']; ?>
list.css">
<div id='phpRecDbList'>
<center>
<form action="" method="POST">
<input type="hidden" name="sent" value="yes">
<input type="submit" value="remove from List">
 
 <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'listCustom.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
 
 </form>
 
 </center>
</div>