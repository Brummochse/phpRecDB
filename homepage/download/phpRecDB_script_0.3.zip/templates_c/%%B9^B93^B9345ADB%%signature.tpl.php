<?php /* Smarty version 2.6.26, created on 2010-05-26 01:07:19
         compiled from signature.tpl */ ?>
<?php if ($this->_tpl_vars['signature'] != 'noSign'): ?>
<div id="sign">
Powered by <a href="http://www.phprecdb.de.vu">phpRecDB</a> Version 0.3
</div>
<?php endif; ?>