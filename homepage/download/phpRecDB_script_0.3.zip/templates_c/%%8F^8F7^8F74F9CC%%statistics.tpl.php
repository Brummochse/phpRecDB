<?php /* Smarty version 2.6.26, created on 2010-05-24 23:12:42
         compiled from admin/statistics.tpl */ ?>
<br>
<center>
size screenshot folder: <?php echo $this->_tpl_vars['size']; ?>
 MB
<br>
files in screenshot folder: <?php echo $this->_tpl_vars['screenshotCount']; ?>

</center>