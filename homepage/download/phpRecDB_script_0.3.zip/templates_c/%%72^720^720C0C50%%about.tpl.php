<?php /* Smarty version 2.6.26, created on 2010-05-24 18:39:56
         compiled from admin/about.tpl */ ?>
<div style="margin-top:40px;margin-left:40px;border:solid 1px #000000;width:400px;">
<p><b><u>phpRecDB</u></b><p><br>
<p>script version: <?php echo $this->_tpl_vars['scriptVersion']; ?>
<p>
<p>database version: <?php echo $this->_tpl_vars['dbVersion']; ?>
<p>
<p>for updates check <a href="http://www.phprecdb.de.vu">www.phpRecDB.de.vu</a> </p>
</div>