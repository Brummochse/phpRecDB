<?php
include_once "constants.php";
include_once "classes/NavigationBar.php";
include_once "classes/Helper.php";
include_once "classes/CustomListData.php";
include_once "classes/NewsListData.php";

class phpRecDB {

    private $smarty;

    function __construct() {
        include_once Constants :: getLibsFolder() . 'Smarty/Smarty.class.php';
        $this->smarty = new Smarty;
        $this->smarty->template_dir = Constants :: getTemplateFolder();
        $this->smarty->compile_dir = Constants :: getCompileFolder();
    }

    private function setNavBarData($listData) {
        $navBar=NavigationBar::getInstance();
        $navBar->setListData($listData);
    }

    private function finalizeNavBar() {
        $navBar=NavigationBar::getInstance();
        if ($navBar->isJsNeeded()) {
            $navBar->printNavBarJS();
        }
    }

    private function showSelected() {
        $recId=Helper::getAsInt(Constants::getParamRecordId());
        if (!empty ($recId)) {
            $navBar=NavigationBar::getInstance();
            $navBar->setRecordId($recId);
            $this->finalizeNavBar();
            include_once "functions/function.getInfoPage.php";
            getInfoPage($recId);
            return true;
        }

        return false;
    }

    private function outputList($data) {
        $this->finalizeNavBar();
        include_once "classes/PublicList.php";
        $list = new PublicList($data);
        $list->getList($this->smarty);
        $this->smarty->display(Constants :: getTemplateFolder() . "list.tpl");
    }

///////////////////////////////////////////////////////////////////
///////////////// public functions ////////////////////////////////
///////////////////////////////////////////////////////////////////

    public function printNavigationBar() {
        $navBar=NavigationBar::getInstance();
        $navBar->printNavBar();
    }

    /////// lists

    public function printList($bootlegType=VIDEO_AND_AUDIO) {
        $data = new CustomListData($bootlegType);
        $this->setNavBarData($data);
        if ($this->showSelected() == false) {
            $this->outputList($data);
        }
    }

    public function printVideoList() {
        $this->printList(VIDEO);
    }

    public function printAudioList() {
        $this->printList(AUDIO);
    }

    public function printSubList($subListName,$bootlegType=VIDEO_AND_AUDIO) {
        include_once "classes/SubListData.php";
        include_once "classes/SublistMananger.php";

        $sublistMananger = new SublistMananger();
        $subListId = $sublistMananger->getListIdByName($subListName);

        $data = new SubListData($bootlegType, $subListId);
        $this->setNavBarData($data);
        if ($this->showSelected() == false) {
            $this->outputList($data);
        }
    }

    public function printNews($newsCount = 5,$newsType=LAST_DAYS,$bootlegType=VIDEO_AND_AUDIO) {
        include_once "classes/PublicList.php";
        $data = new NewsListData($bootlegType, $newsCount, $newsType);
        $this->setNavBarData($data);
        if ($this->showSelected() == false) {
            $this->finalizeNavBar();
            $list = new PublicList($data);
            $list->setShowArtistSelector(false);
            $list->setShowCreationDate(true);
            $list->getList($this->smarty);
            $this->smarty->display(Constants :: getTemplateFolder() . "list.tpl");
        }
    }

    public function printVideoNews($newsCount = 5,$newsType=LAST_DAYS) {
        $this->printNews($newsCount,$newsType,VIDEO);
    }

    public function printAudioNews($newsCount = 5,$newsType=LAST_DAYS) {
        $this->printNews($newsCount,$newsType,AUDIO);
    }

 }
?>
