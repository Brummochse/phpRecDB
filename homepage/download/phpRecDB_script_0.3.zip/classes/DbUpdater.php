
<?php
define("DB_VERSION", "database_version");

class DbUpdater {

    private $settingsManager = null;
    private $latestDbVersion = 0;
    private $updates = null;

    public function getLatestDbVersion() {
        return $this->latestDbVersion;
    }

    public function DbUpdater() {
        include_once dirname(__FILE__) . "/../constants.php";
        include_once Constants :: getClassFolder() . "SettingsManager.php";
        $this->settingsManager = new SettingsManager();

        $this->loadUpdates();
        $lastUpdate = end($this->updates);
        $this->latestDbVersion = $lastUpdate->getVersion();

    }

    public function getCurrentDbVersion() {
        $dbversion = (float) $this->settingsManager->getPropertyValue(DB_VERSION);

        if (empty ($dbversion)) {
            return 0.1;
        } else {
            return $dbversion;
        }
    }


    public function update() {
        $result=false;
        $currentDbVersion = $this->getCurrentDbVersion();
        //if currentDbVersion is not up-to-date
        if ($currentDbVersion < $this->latestDbVersion) {

            include_once Constants :: getSettingsFolder() . "dbConnection.php";
            dbConnect();

            foreach ($this->updates as $update) {
                if ($update->getVersion() > $currentDbVersion) {
                    $update->execute();

                    $this->settingsManager->setPropertyValue(DB_VERSION,$update->getVersion());

                    $result=true;
                }
            }

        };
        return $result;
    }


    ////////////////////////////////////////////

    private function loadUpdates() {
        $this->updates = array (
                new DbVersion02());
    }

}
interface IDbVerions {
    public function execute();
    public function getVersion();
}

class DbVersion02 implements IDbVerions {
    public function getVersion() {
        return 0.2;
    }

    public function execute() {
        //erstelle Tabelle lists
        $sqlQuery = "CREATE TABLE IF NOT EXISTS lists (" .
                "	id INTEGER UNSIGNED NOT NULL AUTO_INCREMENT," .
                "	label VARCHAR(255) NOT NULL," .
                "	PRIMARY KEY(id)" .
                ")" .
                "TYPE=InnoDB;";
        mysql_query($sqlQuery);

        //erstelle Tabelle sublists
        $sqlQuery = "CREATE TABLE sublists (".
                "	recordings_id INTEGER NOT NULL,".
                "	lists_id INTEGER UNSIGNED NOT NULL,".
                "	UNIQUE ( recordings_id, lists_id ) ,".
                "	FOREIGN KEY (lists_id) REFERENCES lists(id) ON DELETE CASCADE,".
                "	FOREIGN KEY (recordings_id) REFERENCES recordings(id) ON DELETE CASCADE".
                ")".
                "TYPE=InnoDB;";
        mysql_query($sqlQuery);

        $sqlQuery="ALTER TABLE recordings MODIFY created DATETIME;";
        mysql_query($sqlQuery);

        $sqlQuery="ALTER TABLE recordings MODIFY lastmodified DATETIME;";
        mysql_query($sqlQuery);
    }
}

//class DbVersion03 implements IDbVerions {
//	public function getVersion() {
//		return 0.3;	
//	}
//	
//	public function execute() {
//		echo "veriosn 03";
//
//	}
//}

?>
