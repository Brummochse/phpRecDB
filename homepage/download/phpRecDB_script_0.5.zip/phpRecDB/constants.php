<?php
class Constants {

    public static function getCsvImportPath() {
       return dirname(__FILE__) . "/temp/csvimport.csv";
    }

    public static function getSignatureFileName() {
        return "/temp/dynamic_signature.png";
    }

    public static function getDynamicSignatureName() {
        return "/misc/signatur.png";
    }

    public static function getScriptVersion() {
        return "0.5";
    }

    public static function getThumbnaiWith() {
        return 250;
    }
    //////////////////////////////////////
    //////////Folders/////////////////////
    //////////////////////////////////////
    public static function getAdminFolder() {
        return dirname(__FILE__) . "/admin/";
    }
    public static function getSettingsFolder() {
        return dirname(__FILE__) . "/settings/";
    }
    public static function getScreenshotsFolder() {
        return dirname(__FILE__) . "/screenshots/";
    }
    public static function getLibsFolder() {
        return dirname(__FILE__) . "/libs/";
    }
    public static function getFunctionsFolder() {
        return dirname(__FILE__) . "/functions/";
    }
    public static function getTemplateFolder() {
        return dirname(__FILE__) . "/templates/";
    }
    public static function getCompileFolder() {
        return dirname(__FILE__) . "/templates_c/";
    }
    public static function getClassFolder() {
        return dirname(__FILE__) . "/classes/";
    }
    public static function getRootFolder() {
        return dirname(__FILE__) . "/";
    }
    //////////////////////////////////////
    //////////get Parameters/////////////////////
    //////////////////////////////////////
    public static function getParamAdminMenuIndex() {
        return 'lid';
    }

    public static function getParamArtistId() {
        return 'artistid';
    }

    public static function getParamYear() {
        return 'year';
    }

    public static function getParamRecordId() {
        return 'recId';
    }
}
?>