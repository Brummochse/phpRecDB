<?php
function getRelativePathTo($destination) {
    $source =realpath(dirname($_SERVER['SCRIPT_FILENAME']));
    $source=correctPath($source);
    $destination=correctPath($destination);
        
    if ($source==$destination) {
        return '';
    }

    while ($source[0]==$destination[0]) {
        $source=substr($source,1);
        $destination=substr($destination,1);
    }

    $path="";
    while (stripos($source, "/")>0) {
        $source=substr($source,stripos($source, "/")+1);
        $path=$path."../";
    }

    return $path.$destination;
}

function correctPath($path) {
    $path=$path."/";
    $path = str_replace("\\", "/", $path);
    $path = str_replace("//", "/", $path);
    return trim($path);
}


?>
