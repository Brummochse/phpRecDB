<?php
    function evaluateBoolean($c_boolean) {
        if (empty ($c_boolean)) {
            return 0;
        } else {
            return 1;
        }
    }
?>
