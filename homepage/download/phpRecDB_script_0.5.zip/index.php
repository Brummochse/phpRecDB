<html>
    <head>
        <title>phpRecDB Demo</title>
    </head>
    <body>
        <center>
            <h1>phpRecDB Demo</h1>

            <a href="index.php">Home</a>
            <a href="news.php">News</a>
            <a href="records.php">Records</a>
            <br><hr><br>

            This is a demo website using the phpRecDB script.<br>
            You can manage your collection in the <a href="phpRecDB/index.php">administration area</a>.<br/>
            <br>For login use:<br/>
            Username: <b>demo</b><br>
            Password: <b>secret</b><br>


        </center>
    </body>
</html>
