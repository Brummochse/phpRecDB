<?php
include "header.php";
?>
This is a demo website using following functions of the phpRecDB script:
<ul>
    <li>news list with paramters</li>
    <li>video-list</li>
    <li>audio-list</li>
    <li>sublist for favorite Bootlegs</li>
    <li>css customizing</li>
</ul>
<br>
You can manage your collection in the <a href="../phpRecDB/index.php">administration area</a>.<br/>
<br>For login use:<br/>
Username: <b>demo</b><br>
Password: <b>secret</b><br>


<?php
include "footer.php";
?>
