<html>
<head>
<title>Logout Page</title>
<style type="text/css">
<!--
A {text-decoration: underline; color: #003F80;	text-align: center; font-family: Helvetica, Tahoma, Arial, sans-serif; font-size: 14px; }
A:Hover {text-decoration: none; color: #3163CE; }
h1 {font-family: Helvetica, Tahoma, Arial, sans-serif; font-size: 28px; text-align: center; font-weight: bold;}
-->
</style>
</head>
<body bgcolor="#e9e9e9">
<center>
<h1>LOGOUT PAGE</h1>

</center>
</body>
</html>