<?php
include_once dirname(__FILE__) . "/../constants.php";
include_once Constants :: getFunctionsFolder() . "function.getConcertInfo.php";

class ScreenshotsManager {

    public static function getScreenshotName($recordId) {
        $infos=getConcertInfoAsArray($recordId);
        $artist=$infos["artist"];
        $date=$infos["date"];

        $screenshotname=$artist."_".$date;
        $screenshotname=ScreenshotsManager::removeEvilChars($screenshotname);
        $screenshotname=ScreenshotsManager::convertSpaces($screenshotname);
        return $screenshotname;
    }

    private static function removeEvilChars($string) {
        $patterns = array(
                "/\\&/",  # Kaufmaennisches UND
                "/\\</",  # < Zeichen
                "/\\>/",  # > Zeichen
                "/\\?/",  # ? Zeichen
                "/\"/",   # " Zeichen
                "/\\:/",  # : Zeichen
                "/\\|/",  # | Zeichen
                "/\\\\/", # \ Zeichen
                "/\\//",  # / Zeichen
                "/\\*/"   # * Zeichen
        );
        return  preg_replace( $patterns, '', $string );
    }

    private static function convertSpaces($string) {
        $patterns = array(
                "/\\s/",  # Leerzeichen
        );
        return  preg_replace( $patterns, '_', $string );
    }

}

?>
