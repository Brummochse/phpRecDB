<?php
function getRelativePathTo($destination) {
    $source = $_SERVER['DOCUMENT_ROOT'] . $_SERVER['PHP_SELF'];
    $source=correctPath(dirname($source));
    $destination=correctPath($destination);

    if ($source==$destination) {
        return '';
    }

    while ($source[0]==$destination[0]) {
        $source=substr($source,1);
        $destination=substr($destination,1);
    }

    $path="";
    while (stripos($source, "/")>0) {
        $source=substr($source,stripos($source, "/")+1);
        $path=$path."../";
    }

    return $path.$destination;
}

function correctPath($path) {
    $path=$path."/";
    $path = str_replace("\\", "/", $path);
    $path = str_replace("//", "/", $path);
    return trim($path);
}


?>
