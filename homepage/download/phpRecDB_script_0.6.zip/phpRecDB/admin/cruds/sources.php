<?
class ContentPage extends ContentPageEcho {

    public function execute($smarty,$linky) {
        ?>

<link rel="stylesheet" type="text/css" href="cruds/style.css" />
        <?
        $table="sources";
        include "bootlegtypesBased.php";
    }
}
?>
