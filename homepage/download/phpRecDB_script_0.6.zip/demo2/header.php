<html>
    <head>
        <title>phpRecDB Demo 2</title>
        <LINK href="demostyle.css" rel="stylesheet" type="text/css">
        <LINK href="listOverwrite.css" rel="stylesheet" type="text/css">
        <LINK href="navBarOverwrite.css" rel="stylesheet" type="text/css">
        <LINK href="infoOverwrite.css" rel="stylesheet" type="text/css">
    </head>
    <body>
        <center>
            <h1>phpRecDB Demo 2</h1>
            <div id="menu" >
                <a href="index.php">News</a>
                <a href="video.php">Video</a>
                <a href="audio.php">Audio</a>
                <a href="favorites.php">My Favorite Bootlegs</a>
                <a href="about.php">About</a>
            </div>
