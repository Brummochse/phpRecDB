<?php /* Smarty version 2.6.26, created on 2009-11-16 15:56:46
         compiled from printInfo.tpl */ ?>
<font face="Arial" size="+1" ><b><u><?php echo $this->_tpl_vars['artist']; ?>
</u></b></font><br>
<font face="Arial"  size="-3" color="#FFFFFF">_</font><br>
<font face="Arial" ><b><?php echo $this->_tpl_vars['date']; ?>
</b></font><br>
<font face="Arial"  size="-3" color="#FFFFFF">_</font><br>
<font face="Arial" size=""><b><?php echo $this->_tpl_vars['country']; ?>
 - <?php echo $this->_tpl_vars['city']; ?>

<br><?php echo $this->_tpl_vars['venue']; ?>
 <?php if ($this->_tpl_vars['supplement'] != ''): ?><br><?php endif; ?><?php echo $this->_tpl_vars['supplement']; ?>
</b></font>
<?php if ($this->_tpl_vars['misc'] != ''): ?><br><font face="Arial" size="+1"><b><?php echo $this->_tpl_vars['misc']; ?>
</b></font><?php endif; ?><br>
<font face="Arial"  size="-3" color="#FFFFFF">_</font>
<?php if ($this->_tpl_vars['sourceidentification'] != ''): ?><br><font><b><i>Version: <?php echo $this->_tpl_vars['sourceidentification']; ?>
</i></b></font><?php endif; ?>