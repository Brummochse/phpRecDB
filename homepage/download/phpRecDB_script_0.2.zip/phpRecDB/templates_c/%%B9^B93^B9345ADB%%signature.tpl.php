<?php /* Smarty version 2.6.26, created on 2009-11-16 03:29:40
         compiled from signature.tpl */ ?>
<div id="sign">
Powered by <a href="http://www.phprecdb.de.vu">phpRecDB</a>
</div>