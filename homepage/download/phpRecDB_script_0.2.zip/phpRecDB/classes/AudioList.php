<?php
include_once "InfoList.php";

class AudioList extends InfoList {
	
	function AudioList() {
		parent :: InfoList();
		$this->setBootlegType(2);
	}
	
	function getRecordsForArtist() {
	$sqlSelect = "SELECT concerts.id, artists.name, concerts.date, countrys.name, citys.name, venues.name, concerts.supplement, concerts.misc,recordings.id, recordings.sumlength,media.label,rectypes.shortname,sources.shortname,recordings.quality,recordings.sourceidentification,tradestatus.shortname,artists.id,YEAR(date),recordings.created,'' " .
		"FROM concerts " .
		"LEFT OUTER JOIN artists ON artists.id = concerts.artists_id " .
		"LEFT OUTER JOIN countrys ON countrys.id = concerts.countrys_id " .
		"LEFT OUTER JOIN citys ON citys.id = concerts.citys_id " .
		"LEFT OUTER JOIN venues ON venues.id = concerts.venues_id " .
		"LEFT OUTER JOIN recordings ON concerts.id = recordings.concerts_id " .
		"LEFT OUTER JOIN media ON media.id = recordings.media_id " .
		"LEFT OUTER JOIN rectypes ON rectypes.id = recordings.rectypes_id " .
		"LEFT OUTER JOIN sources ON sources.id = recordings.sources_id " .
		"LEFT OUTER JOIN tradestatus ON tradestatus.id = recordings.tradestatus_id " .
		"INNER JOIN audio ON audio.recordings_id = recordings.id " .
		"WHERE artists.id=" . $this->artistId . " " .		
		"ORDER BY artists.name, concerts.misc, concerts.date,concerts.id,recordings.sumlength DESC";
		$concerts = mysql_query($sqlSelect) or die("MySQL-Error: " . mysql_error());
		$this->setShowCreationDate(false);
		$this->setShowRecordCount(true);
		return $concerts;
	}
	
	function getAllRecords() {
		$sqlSelect = "SELECT concerts.id, artists.name, concerts.date, countrys.name, citys.name, venues.name, concerts.supplement, concerts.misc,recordings.id, recordings.sumlength,media.label,rectypes.shortname,sources.shortname,recordings.quality,recordings.sourceidentification,tradestatus.shortname,artists.id,YEAR(date),recordings.created,'' " .
		"FROM concerts " .
		"LEFT OUTER JOIN artists ON artists.id = concerts.artists_id " .
		"LEFT OUTER JOIN countrys ON countrys.id = concerts.countrys_id " .
		"LEFT OUTER JOIN citys ON citys.id = concerts.citys_id " .
		"LEFT OUTER JOIN venues ON venues.id = concerts.venues_id " .
		"LEFT OUTER JOIN recordings ON concerts.id = recordings.concerts_id " .
		"LEFT OUTER JOIN media ON media.id = recordings.media_id " .
		"LEFT OUTER JOIN rectypes ON rectypes.id = recordings.rectypes_id " .
		"LEFT OUTER JOIN sources ON sources.id = recordings.sources_id " .
		"LEFT OUTER JOIN tradestatus ON tradestatus.id = recordings.tradestatus_id " .
		"INNER JOIN audio ON audio.recordings_id = recordings.id " .
		"ORDER BY artists.name, concerts.misc, concerts.date,concerts.id,recordings.sumlength DESC";
		$concerts = mysql_query($sqlSelect) or die("MySQL-Error: " . mysql_error());
		$this->setShowCreationDate(false);
		$this->setShowRecordCount(true);
		return $concerts;
	}
}
?>
