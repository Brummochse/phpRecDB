 <?php
include_once "AudioList.php";

class AudioNewsList extends AudioList {

	private $oldestDate;
	
	function AudioNewsList($newsCount) {
		parent :: InfoList();
		$this->evaluateLastDate($newsCount);
	}
	
	function getAllRecords() {
		$sqlSelect = "SELECT concerts.id, artists.name, concerts.date, countrys.name, citys.name, venues.name, concerts.supplement, concerts.misc,recordings.id, recordings.sumlength,media.label,rectypes.shortname,sources.shortname,recordings.quality,recordings.sourceidentification,tradestatus.shortname,artists.id,YEAR(date),recordings.created,'' " .
		"FROM concerts " .
		"LEFT OUTER JOIN artists ON artists.id = concerts.artists_id " .
		"LEFT OUTER JOIN countrys ON countrys.id = concerts.countrys_id " .
		"LEFT OUTER JOIN citys ON citys.id = concerts.citys_id " .
		"LEFT OUTER JOIN venues ON venues.id = concerts.venues_id " .
		"LEFT OUTER JOIN recordings ON concerts.id = recordings.concerts_id " .
		"LEFT OUTER JOIN media ON media.id = recordings.media_id " .
		"LEFT OUTER JOIN rectypes ON rectypes.id = recordings.rectypes_id " .
		"LEFT OUTER JOIN sources ON sources.id = recordings.sources_id " .
		"LEFT OUTER JOIN tradestatus ON tradestatus.id = recordings.tradestatus_id " .
		"INNER JOIN audio ON audio.recordings_id = recordings.id " .
		"WHERE recordings.created>='" . $this->oldestDate . "'" .
		"ORDER BY recordings.created DESC,artists.name, concerts.misc, concerts.date,concerts.id";
		$concerts = mysql_query($sqlSelect) or die("MySQL-Error: " . mysql_error());
		$this->setShowCreationDate(true);
		$this->setShowRecordCount(false);
		return $concerts;
	}
	
	public function evaluateLastDate($newsCount) {
		$this->setShowArtistSelector(false);
		$newsCount=(int)$newsCount;
		$sqlSelect = "SELECT DISTINCT recordings.created " .
		"FROM concerts " .
		"LEFT OUTER JOIN recordings ON concerts.id = recordings.concerts_id " .
		"INNER JOIN audio ON audio.recordings_id = recordings.id ".
		"ORDER BY recordings.created DESC " .
		"LIMIT 0 , ".$newsCount;
		$updateDates = mysql_query($sqlSelect) or die("MySQL-Error: " . mysql_error());
		while ($date = mysql_fetch_row($updateDates)) {
			$this->oldestDate=$date[0];
		}
	}
}

?>
