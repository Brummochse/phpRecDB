<?php
abstract class ListBuilder {

	protected $artistId = null;
	protected $selectedYear = null;
	protected $years = array ();
	protected $templateAlternate;
	private $artists = array ();
	private $showYears = false;
	private $showArtistSelector = false;
	private $showRecordCount = true;
	private $showCreationDate = false;
	private $signatureVisibility = true;

	//1=video 2=audio
	private $bootlegType = 1;

	public function setSignatureVisibility($signatureVisibility) {
		$this->signatureVisibility = $signatureVisibility;
	}

	public function setBootlegType($bootlegType) {
		$this->bootlegType = $bootlegType;
	}

	public function setShowArtistSelector($showArtistSelector) {
		$this->showArtistSelector = $showArtistSelector;
	}

	public function setShowCreationDate($showCreationDate) {
		$this->showCreationDate = $showCreationDate;
	}

	function ListBuilder() {
		include_once dirname(__FILE__) . "/../settings/dbConnection.php";
		include_once dirname(__FILE__) . '/../libs/Smarty/Smarty.class.php';

		if (isset ($_GET['artistid'])) {
			$artistId = (int) $_GET['artistid'];
			if (!empty ($artistId)) {
				$this->artistId = $artistId;
				$this->showYears = true;
			}
		}
		if (isset ($_GET['year'])) {
			$year = (int) $_GET['year'];
			if (!empty ($year)) {
				$this->selectedYear = $year;
			}
		}
		$this->showArtistSelector = !$this->showYears;
		dbConnect();
	}

	public function setShowRecordCount($showRecordCount) {
		$this->showRecordCount = $showRecordCount;
	}

	public function setArtistId($artistId) {
		$this->artistId = (int) $artistId;
	}

	public function setSelectedYear($selectedYear) {
		$this->selectedYear = (int) $selectedYear;
	}

	function getAllRecords() {
		$sqlSelect = "SELECT concerts.id, artists.name, concerts.date, countrys.name, citys.name, venues.name, concerts.supplement, concerts.misc,recordings.id, recordings.sumlength,media.shortname,rectypes.shortname,sources.shortname,recordings.quality,recordings.sourceidentification,tradestatus.shortname,artists.id,YEAR(date),recordings.created,videoformat.label " .
		"FROM concerts " .
		"LEFT OUTER JOIN artists ON artists.id = concerts.artists_id " .
		"LEFT OUTER JOIN countrys ON countrys.id = concerts.countrys_id " .
		"LEFT OUTER JOIN citys ON citys.id = concerts.citys_id " .
		"LEFT OUTER JOIN venues ON venues.id = concerts.venues_id " .
		"LEFT OUTER JOIN recordings ON concerts.id = recordings.concerts_id " .
		"LEFT OUTER JOIN media ON media.id = recordings.media_id " .
		"LEFT OUTER JOIN rectypes ON rectypes.id = recordings.rectypes_id " .
		"LEFT OUTER JOIN sources ON sources.id = recordings.sources_id " .
		"LEFT OUTER JOIN tradestatus ON tradestatus.id = recordings.tradestatus_id " .
		"INNER JOIN video ON video.recordings_id = recordings.id " .
		"LEFT OUTER JOIN videoformat ON videoformat.id = video.videoformat_id " .
		"ORDER BY artists.name, concerts.misc, concerts.date,concerts.id,recordings.sumlength DESC";
		$concertsSql = mysql_query($sqlSelect) or die("MySQL-Error: " . mysql_error());
		$this->setShowCreationDate(false);
		$this->setShowRecordCount(true);
		return $concertsSql;
	}

	function getRecordsForArtist() {
		$sqlSelect = "SELECT concerts.id, artists.name, concerts.date, countrys.name, citys.name, venues.name, concerts.supplement, concerts.misc,recordings.id, recordings.sumlength,media.label,rectypes.shortname,sources.shortname,recordings.quality,recordings.sourceidentification,tradestatus.shortname,artists.id,YEAR(date),recordings.created,videoformat.label " .
		"FROM concerts " .
		"LEFT OUTER JOIN artists ON artists.id = concerts.artists_id " .
		"LEFT OUTER JOIN countrys ON countrys.id = concerts.countrys_id " .
		"LEFT OUTER JOIN citys ON citys.id = concerts.citys_id " .
		"LEFT OUTER JOIN venues ON venues.id = concerts.venues_id " .
		"LEFT OUTER JOIN recordings ON concerts.id = recordings.concerts_id " .
		"LEFT OUTER JOIN media ON media.id = recordings.media_id " .
		"LEFT OUTER JOIN rectypes ON rectypes.id = recordings.rectypes_id " .
		"LEFT OUTER JOIN sources ON sources.id = recordings.sources_id " .
		"LEFT OUTER JOIN tradestatus ON tradestatus.id = recordings.tradestatus_id " .
		"INNER JOIN video ON video.recordings_id = recordings.id " .
		"LEFT OUTER JOIN videoformat ON videoformat.id = video.videoformat_id " .
		"WHERE artists.id=" . $this->artistId . " " .
		"ORDER BY artists.name, concerts.misc, concerts.date, concerts.id";
		$concerts = mysql_query($sqlSelect) or die("MySQL-Error: " . mysql_error());
		$this->setShowCreationDate(false);
		$this->setShowRecordCount(true);
		return $concerts;
	}

	protected function getRecords() {
		if ($this->artistId != null) {
			return $this->getRecordsForArtist();
		} else {
			return $this->getAllRecords();
		}
	}

	public function getList() {
		$this->artists = array ();
		$concerts = array ();
		$currentConcert = null;
		$concertsSql = $this->getRecords();
		$this->templateAlternate = false;
		$lastArtist = '';
		$lastArtistsId = -1;
		$lastConcertId = -1;
		$lastRecordCreated = null;
		$lastYear = '';
		$lastMisc = -1;
		$firstrun = true;
		$recordCounter = 0;
		$counter = 0;
		while ($concert = mysql_fetch_row($concertsSql)) {
			foreach ($concert AS $key => $value) {
				$concert[$key] = stripslashes($value);
			}

			$concertId = $concert[0];
			$artist = $concert[1];
			$date = $concert[2];
			$country = $concert[3];
			$city = $concert[4];
			$venue = $concert[5];
			$supplement = $concert[6];
			$misc = $concert[7];
			$recordingId = $concert[8];
			$length = $concert[9];
			$medium = $concert[10];
			$rectype = $concert[11];
			$source = $concert[12];
			$quality = $concert[13];
			$sourceidentification = $concert[14];
			$tradestatus = $concert[15];
			$artistsId = $concert[16];
			$year = $concert[17];
			$created = $concert[18];
			$videoformat = $concert[19];

			if ($this->filterName != null && $this->artistId == null) {
				if (!$this->checkFilter($artist, $country, $city, $venue, $medium, $rectype, $source, $tradestatus)) {
					continue;
				}
			}

			if (!empty ($this->selectedYear)) {
				if ($this->selectedYear != $year) {
					continue;
				}
			}
			$counter++;

			if ($lastArtist != $artist || $lastMisc != $misc) {
				$this->templateAlternate = false;
			}
			if ($lastConcertId == $concertId) {
				$this->templateAlternate = !$this->templateAlternate;
			}
			if ($this->templateAlternate) {
				$templateAlternate = 'true';
			} else {
				$templateAlternate = 'false';
			}

			$record = array (
				"templateAlternate" => $templateAlternate,
				"sourceidentification" => $sourceidentification,
				"quality" => $quality,
				"length" => $length,
				"type" => $rectype,
				"medium" => $medium,
				"source" => $source,
				"videoformat" => $videoformat,
				"buttons" => $this->getButtons($recordingId
			), "tradestatus" => $tradestatus);

			if ($this->showCreationDate && $lastRecordCreated != $created) {
				$record['creationDate'] = $created;
			}

			if (($lastConcertId != $concertId) || ($this->showCreationDate && $lastRecordCreated != $created)) {
				if ($currentConcert != null) {
					array_push($concerts, $currentConcert);
				}
				$currentConcert = array (
					"date" => $date,
					"country" => $country,
					"city" => $city,
					"venue" => $venue,
					"supplement" => $supplement,
					"records" => array (
						$record
					)
				);
			} else {
				array_push($currentConcert["records"], $record);
				$currentConcert["recordcount"] = count($currentConcert["records"]);
			}

			if ($lastArtist != $artist || $lastMisc != $misc || ($this->showCreationDate && $lastRecordCreated != $created)) {
				$lastYear = '';
				if (!$firstrun) {
					$this->addArtist($lastArtist, $lastArtistsId, $lastMisc, $recordCounter, $concerts);
				}
				$recordCounter = 1;
				$concerts = array ();
			} else {
				$recordCounter++;
			}

			if ($this->showYears && $year != $lastYear) {
				$yearLink = $this->getYearLink($year);
				$currentConcert["newYearLink"] = $yearLink;
				$currentConcert["newYear"] = $year;
				$this->years[$year] = $yearLink;
			}

			$this->templateAlternate = !$this->templateAlternate;

			$lastArtist = $artist;
			$lastArtistsId = $artistsId;
			$lastConcertId = $concertId;
			$lastRecordCreated = $created;
			$lastMisc = $misc;
			$lastYear = $year;
			$firstrun = false;
		}
		array_push($concerts, $currentConcert);
		$this->addArtist($lastArtist, $lastArtistsId, $lastMisc, $recordCounter, $concerts);

		$smarty = new Smarty;
		include_once dirname(__FILE__) . "/../constants.php";
		$smarty->template_dir = Constants::getTemplateFolder();
		$smarty->compile_dir = Constants::getCompileFolder();

		$smarty->assign("artists", $this->artists);
		if ($this->showRecordCount)
			$smarty->assign("reccount", $counter);

		if ($this->showArtistSelector) {
			$smarty->assign('artistSelector', $this->getBandsSelector());
		}

		include_once Constants::getFunctionsFolder() . 'function.getRelativePathTo.php';

		$smarty->assign("relativeTemplatesPath", getRelativePathTo(Constants::getTemplateFolder()));
		$smarty->assign("bootlegType", $this->bootlegType);

		if ($this->signatureVisibility == false) {
			$smarty->assign("signature", 'noSign');
		}

		$smarty->display(Constants::getTemplateFolder() . "list.tpl");
	}

	function getYearLink($year) {
		return $this->makeUrl(array (
			'artistid' => $this->artistId,
			'year' => $year
		));
	}

	function getArtistLink($artistId) {
		return $this->makeUrl(array (
			'artistid' => $artistId,
			'year' => null
		));
	}

	function addArtist($lastArtist, $lastArtistId, $lastMisc, $recordCounter, $concerts) {
		if ($lastMisc == '1') {
			$miscText = '(misc)';
		} else {
			$miscText = '';
		}
		$artist = array (
			"name" => $lastArtist,
			"id" => $lastArtistId,
			"misc" => $miscText,
			"link" => $this->getArtistLink($lastArtistId
		), "recordcount" => $recordCounter, "concerts" => $concerts, "years" => $this->getYearsSelector());
		array_push($this->artists, $artist);
	}

	function getYearsSelector() {
		if (!empty ($this->selectedYear) || count($this->years) <= 1) {
			return "";
		}
		$yearsHtml = "<form name='yearForm' method='get' action='" . basename($GLOBALS['_SERVER']['PHP_SELF']) . "'>" .
		$this->createHiddenInputs(array (
			'artistid' => $this->artistId
		)) .
		"<select name='year' onchange='submit();'><option>Year</option>";
		foreach ($this->years as $year => $link) {
			$yearsHtml = $yearsHtml . "<option>" . $year . "</option>";
		}
		$yearsHtml = $yearsHtml . "</select></form>";
		$this->years = array ();
		return $yearsHtml;
	}

	function getBandsSelector() {
		$counter = 0;
		$bandsHtml = "<form name='artistForm' method='get' action='" . basename($GLOBALS['_SERVER']['PHP_SELF']) . "'>" .
		$this->createHiddenInputs() .
		"<select name='artistid' onchange='submit();'><option>Artist</option>";
		foreach ($this->artists as $artist) {
			if (empty ($artist['misc'])) {
				$bandsHtml = $bandsHtml . "<option value='" . $artist['id'] . "'>" . $artist['name'] . "</option>";
				$counter++;
			}
		}
		$bandsHtml = $bandsHtml . "</select></form>";
		if ($counter > 1) {
			return $bandsHtml;
		} else {
			return "";
		}
	}

	private function createHiddenInputs($overGet = array ()) {
		$get = $GLOBALS['_GET'];

		foreach ($overGet as $k => $v) {
			$get[$k] = $v;
		}

		$ga = array ();
		foreach ($get as $k => $v) {
			$ga[] = "<input type='hidden' name='" . urlencode($k) . "' value='" . urlencode($v) . "'>";
		}
		return implode($ga);
	}

	protected function makeUrl($overGet = array ()) {
		$get = $GLOBALS['_GET'];

		// overWrite GET
		foreach ($overGet as $k => $v) {
			$get[$k] = $v;
		}
		// make Url
		$ga = array ();
		foreach ($get as $k => $v) {
			$ga[] = urlencode($k) . "=" . urlencode($v);
		}
		//
		return basename($GLOBALS['_SERVER']['PHP_SELF']) . "?" . implode("&", $ga);
	}

	public function setFilter($filterName, $filterValue) {
		$this->filterName = $filterName;
		$this->filterValue = $filterValue;

		$this->showArtistSelector = false;
		if ($this->filterName == 'ARTISTNAME') {
			$this->showYears = true;
		}
	}

	private $filterName = null;
	private $filterValue = null;

	private function checkFilter($artist, $country, $city, $venue, $medium, $rectype, $source, $tradestatus) {
		$result = false;
		if ($this->filterName == 'ARTISTNAME')
			$result = $artist == $this->filterValue;
		if ($this->filterName == 'COUNTRY')
			$result = $country == $this->filterValue;
		if ($this->filterName == 'CITY')
			$result = $city == $this->filterValue;
		if ($this->filterName == 'VENUE')
			$result = $venue == $this->filterValue;
		if ($this->filterName == 'MEDIA')
			$result = $medium == $this->filterValue;
		if ($this->filterName == 'RECORDINGTYPE')
			$result = $rectype == $this->filterValue;
		if ($this->filterName == 'SOURCE')
			$result = $source == $this->filterValue;
		if ($this->filterName == 'TRADESTATUS')
			$result = $tradestatus == $this->filterValue;
		if ($result) {
			return true;
		} else {
			return false;
		}
	}
}
?>