<?php
class Constants {
	public static function getThumbnaiWith() {
		return 250;
	}
	//////////////////////////////////////
	//////////Folders/////////////////////
	//////////////////////////////////////
	public static function getAdminFolder() {
		return dirname(__FILE__) . "/admin/";
	}
	public static function getSettingsFolder() {
		return dirname(__FILE__) . "/settings/";
	}
	public static function getScreenshotsFolder() {
		return dirname(__FILE__) . "/screenshots/";
	}
	public static function getLibsFolder() {
		return dirname(__FILE__) . "/libs/";
	}
	public static function getFunctionsFolder() {
		return dirname(__FILE__) . "/functions/";
	}
	public static function getTemplateFolder() {
		return dirname(__FILE__) . "/templates/";
	}
	public static function getCompileFolder() {
		return dirname(__FILE__) . "/templates_c/";
	}
	public static function getClassFolder() {
		return dirname(__FILE__) . "/classes/";
	}
}
?>