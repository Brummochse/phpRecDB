<div style="margin-top:40px;margin-left:40px;border:solid 1px #000000;width:400px;">
<p><b><u>phpRecDB</u></b><p><br>
<p>script version: 0.2<p>
<p>database schema version: 0.1<p><br>
<p>for updates check <a href="http://www.phprecdb.de.vu">www.phpRecDB.de.vu</a> </p>
</div>