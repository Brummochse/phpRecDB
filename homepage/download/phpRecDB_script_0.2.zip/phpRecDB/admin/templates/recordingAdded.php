<?
include_once dirname(__FILE__) . "/../../constants.php";
include_once Constants::getClassFolder() . "Linky.php";
$linky = new Linky("lid");
$editRecordLink="index.php".$linky->encryptName('edit Record', array (
	'id' => $recordingId
));
?>

<p>Recording Added Successfully with RecordingID: (<?= $recordingId ?>)!</p>
<p>
<? if ($c_videoOrAudio=='video'): ?> 
	videoId: (<? echo $videoId ?>)
<? endif; ?> 

<? if ($c_videoOrAudio=='audio'): ?> 
	audioId: (<? echo $audioId ?>)
<? endif; ?> 
</p>

<p><a href='<?= $editRecordLink ?>'>edit Recording</a></p>