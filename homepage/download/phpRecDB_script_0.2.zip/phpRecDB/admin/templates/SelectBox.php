<select name="<?=$name ?>" size="1">
	<option value="NULL" >-</option>
	<?php  while ($row = mysql_fetch_row($results)): ?>
	<?php if ($currentValue==$row[0]): ?>
	<option value="<?= $row[0] ?>" selected><?= $row[1] ?></option>
	<?php else : ?>
	<option value="<?= $row[0] ?>"><?= $row[1] ?></option>
	<?php endif; ?>
<?php  endwhile; ?> 
</select>
