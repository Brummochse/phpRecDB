<h2><?php  echo $c_artist; ?><h2>
<h3><?php  echo $c_date; ?></h3>
<?php if ($miscBoolean): ?> 
	<h5>MISC</h5>
<?php endif; ?> 

<form method="POST" action="appendRecording.php" name="formular" >
	<table>
		<tr>
			<td>
				<input type="radio" name="select" value="new" checked> 
			</td>
			<td>
				new Entry
			</td>
		</tr>
		 <?php  while ($concert = mysql_fetch_row($concerts)): ?>
		<tr>
			<td>
				<input type="radio" name="select" value="<? echo $concert[0] ?>"> 
			</td>
			<td>
				<? echo $concert[1]." ".$concert[2]." ".$concert[3]." ".$concert[4]." ".$concert[5]; ?>
			</td>
		</tr>
		 <?php  endwhile; ?> 
	</table>
	<input type="submit">
</form>