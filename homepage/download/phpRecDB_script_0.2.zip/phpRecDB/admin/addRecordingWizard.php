<?php
include_once "../constants.php";
include_once ('../libs/Smarty/Smarty.class.php');

$smarty = new Smarty;
$smarty->template_dir = Constants::getTemplateFolder();
$smarty->compile_dir = Constants::getCompileFolder();

$smarty->assign('addConcertLink', 'editConcert.php');
$smarty->assign('audioOrVideoSelection', 'true');
$smarty->assign("relativeTemplatesPath", getRelativePathTo(Constants::getTemplateFolder()));
$smarty->display("editConcert.tpl");
?>