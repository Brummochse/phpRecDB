<?php
include_once "../constants.php";
include_once Constants::getFunctionsFolder() . "functions.watermark.php";
include_once Constants::getFunctionsFolder() . 'function.getRelativePathTo.php';
include_once ('../libs/Smarty/Smarty.class.php');
include_once Constants::getClassFolder() . "SettingsManager.php";
include_once Constants::getClassFolder() . "ScreenshotUploader.php";

$previewThumbnailFileName = "watermarkpreviewThumb.jpg";
$previewFileName = "watermarkpreview.jpg";
$fontsFolder = "fonts/";

$smarty = new Smarty;
$smarty->template_dir = Constants::getTemplateFolder();
$smarty->compile_dir = Constants::getCompileFolder();
$smarty->assign("relativeTemplatesPath", getRelativePathTo(Constants::getTemplateFolder()));

$settingsManager = new SettingsManager();

if (isset ($_POST['submitted'])) {
	foreach ($_POST AS $key => $value) {
		$_POST[$key] = mysql_real_escape_string($value);
	}
	$textenable = $_POST['textenabled'];
	$text = $_POST['text'];
	$fontsize = $_POST['fontsize'];
	$textborder = $_POST['textborder'];
	$align = $_POST['align'];
	$valign = $_POST['valign'];
	$fontstyle = $_POST['fontstyle'];
	$red = $_POST['red'];
	$green = $_POST['green'];
	$blue = $_POST['blue'];
	$thumbailenabled = $_POST['thumbailenabled'];
	$resizeenabled = $_POST['resizeenabled'];
	
	$settingsManager->setPropertyValue(TEXTENABLED, $textenable);
	$settingsManager->setPropertyValue(TEXT, $text);
	$settingsManager->setPropertyValue(FONTSIZE, $fontsize);
	$settingsManager->setPropertyValue(TEXTBORDER, $textborder);
	$settingsManager->setPropertyValue(ALIGN, $align);
	$settingsManager->setPropertyValue(VALIGN, $valign);
	$settingsManager->setPropertyValue(FONTSTYLE, $fontstyle);
	$settingsManager->setPropertyValue(RED, $red);
	$settingsManager->setPropertyValue(GREEN, $green);
	$settingsManager->setPropertyValue(BLUE, $blue);
	$settingsManager->setPropertyValue(THUMBNAIL, $thumbailenabled);
	$settingsManager->setPropertyValue(RESIZETHUMBNAIL, $resizeenabled);	

} else {
	if (!$settingsManager->containsProperty(TEXTENABLED)) {
		setDefaults($settingsManager);
	}
	$textenable = $settingsManager->getPropertyValue(TEXTENABLED);
	$text = $settingsManager->getPropertyValue(TEXT);
	$fontsize = $settingsManager->getPropertyValue(FONTSIZE);
	$textborder = $settingsManager->getPropertyValue(TEXTBORDER);
	$align = $settingsManager->getPropertyValue(ALIGN);
	$valign = $settingsManager->getPropertyValue(VALIGN);
	$fontstyle = $settingsManager->getPropertyValue(FONTSTYLE);
	$red = $settingsManager->getPropertyValue(RED);
	$green = $settingsManager->getPropertyValue(GREEN);
	$blue = $settingsManager->getPropertyValue(BLUE);
	$thumbailenabled = $settingsManager->getPropertyValue(THUMBNAIL);
	$resizeenabled = $settingsManager->getPropertyValue(RESIZETHUMBNAIL);
}

$smarty->assign('textenabled', $textenable);
$smarty->assign('text', $text);
$smarty->assign('fontsize', $fontsize);
$smarty->assign('textborder', $textborder);
$smarty->assign('align', array (
	"left" => "left",
	"center" => "center",
	"right" => "right"
));
$smarty->assign('align_id', $align);
$smarty->assign('valign', array (
	"top" => "top",
	"middle" => "middle",
	"bottom" => "bottom"
));
$smarty->assign('valign_id', $valign);
$smarty->assign('fontstyles', getAvailableFonts($fontsFolder));
$smarty->assign('fontstyleSelection', $fontstyle);
$smarty->assign('red', $red);
$smarty->assign('green', $green);
$smarty->assign('blue', $blue);
$smarty->assign('thumbailenabled', $thumbailenabled);
$smarty->assign('resizeenabled', $resizeenabled);
$smarty->assign('previewPicturePath', createSampleScreenshotAndGetPath($textenable,$fontsize,$fontstyle,$textborder,$align,$valign,$text,$red,$green,$blue));
$smarty->assign('previewThumbnailPath', createSampleThumbnailAndGetPath($textenable,$fontsize,$fontstyle,$textborder,$align,$valign,$text,$red,$green,$blue));



$smarty->display("watermark.tpl");

function createSampleScreenshotAndGetPath($textenable,$fontsize,$fontstyle,$textborder,$align,$valign,$text,$red,$green,$blue) {
	global $previewFileName;
	global $fontsFolder;
	
	$picture = @ imagecreate(720, 576) or die('Cannot Initialize new GD image stream');
	imagecolorallocate($picture, 0, 0, 0);
	$savePath = Constants::getScreenshotsFolder() . $previewFileName;

	if ($textenable == true) {
		$color = ImageColorAllocate($picture, $red, $green, $blue);
		$fontfile = $fontsFolder . $fontstyle;

		imagestringbox($picture, $fontsize, $fontfile, $textborder, $align, $valign, $text, $color);
	}
	imagejpeg($picture, $savePath, 70);
	imageDestroy($picture);
	$path=getRelativePathTo(Constants::getScreenshotsFolder()) . $previewFileName . "?rnd=" . time();
	return $path;
}

function createSampleThumbnailAndGetPath($textenable,$fontsize,$fontstyle,$textborder,$align,$valign,$text,$red,$green,$blue) {
	global $previewThumbnailFileName;
	global $fontsFolder;
	
	$picture = @ imagecreate(720, 576) or die('Cannot Initialize new GD image stream');
	imagecolorallocate($picture, 0, 0, 0);
	$savePath = Constants::getScreenshotsFolder() . $previewThumbnailFileName;

	$screenshotUploader=new ScreenshotUploader();
	$thumbnailImage=$screenshotUploader->createThumbnail($picture);
	
	imagejpeg($thumbnailImage, $savePath, 70);
	imageDestroy($picture);
	imageDestroy($thumbnailImage);
	$path=getRelativePathTo(Constants::getScreenshotsFolder()) . $previewThumbnailFileName . "?rnd=" . time();
	return $path;
}

function setDefaults($settingsManager) {
	$settingsManager->setPropertyValue(TEXTENABLED, 0);
	$settingsManager->setPropertyValue(TEXT, '(C) phpRecDB');
	$settingsManager->setPropertyValue(FONTSIZE, 20);
	$settingsManager->setPropertyValue(TEXTBORDER, 10);
	$settingsManager->setPropertyValue(ALIGN, 'left');
	$settingsManager->setPropertyValue(VALIGN, 'top');
	$settingsManager->setPropertyValue(FONTSTYLE, 'ARIAL.TTF');
	$settingsManager->setPropertyValue(RED, 255);
	$settingsManager->setPropertyValue(GREEN, 0);
	$settingsManager->setPropertyValue(BLUE, 0);
	$settingsManager->setPropertyValue(THUMBNAIL, 1);
	$settingsManager->setPropertyValue(RESIZETHUMBNAIL, 1);
}

function getAvailableFonts($fontFolderPAth) {
	$fontstyles = array ();
	$dp = opendir($fontFolderPAth);
	while ($file = readdir($dp)) {
		$filepath = dirname(__FILE__);
		if (strlen($file) > 3) {
			array_push($fontstyles, $file);
		}
	}
	closedir($dp);
	return $fontstyles;
}
?> 
