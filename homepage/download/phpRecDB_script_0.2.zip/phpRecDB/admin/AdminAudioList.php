
  <link rel="stylesheet" type="text/css" href="../listtamplate.css">
  <script language="javascript" >
     function deleteRecord(url)
     {
     	if (confirm('Do you really want to delete this record?'))
     	location.href = url;
     }
     function pop(url,pictureId,width,height) {
		width=width+30;
		height=height+30;
	
		var attr = 'width='+width+',height='+height+',location=no,menubar=no,toolbar=no,status=no,resizable=no,scrollbars=no';
		var newWindow=window.open(url,'max_picture'+pictureId,attr);
		newWindow.focus(); 
	}
    </script>
     <br>
 <br>
 <?php
include_once "../classes/AudioList.php";
include_once "../constants.php";
include_once Constants::getClassFolder() . "Linky.php";

class AdminAudioList extends AudioList {

	private $linky;
	function AdminAudioList() {
		$this->linky = new Linky("lid");
		parent :: AudioList();

	}

	function getEditLink($recordingsId) {
		$url = $this->linky->encryptName('edit Record', array (
			'id' => $recordingsId
		));
		$link = "<a href='$url'>edit</a>";
		return $link;
	}

	function getDeleteLink($recordingsId) {
		$link = "<a href=\"javascript:deleteRecord('" . $this->linky->encryptName('delete Record', array (
			'id' => $recordingsId
		)) . "')\">delete</a>";

		return $link;
	}

	function getPrintinfoLink($recordingsId) {
		$printInfoURL = "PrintInfo.php";
		$param = "?id=$recordingsId";
		$url = $printInfoURL . $param;
		$link = "<a target='_blank' href='$url' onclick='javascript:pop(this.href,1,373,560); return false'>PrintInfo</a>";

		return $link;
	}

	function getButtons($recordingId) {
		return $this->getEditLink($recordingId) . " " . $this->getDeleteLink($recordingId) . " " . $this->getPrintinfoLink($recordingId);
	}

}

$adminList = new AdminAudioList();
$adminList->getList();

?>
