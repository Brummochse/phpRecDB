<link rel="stylesheet" type="text/css" href="cruds/style.css" />
<?
$table="media";
include "bootlegtypesBased.php"
?>