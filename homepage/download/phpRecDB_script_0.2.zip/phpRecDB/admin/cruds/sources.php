<link rel="stylesheet" type="text/css" href="cruds/style.css" />
<?
$table="sources";
include "bootlegtypesBased.php"
?>
