<?php
function createRecordAndGetId($concertId) {
	$sqlInsertNewRecording = "INSERT INTO recordings (concerts_id,created) VALUES (" . $concertId . ",NOW());";
	mysql_query($sqlInsertNewRecording) or die("MySQL-Error: " . mysql_error());
	$recordingId = mysql_insert_id();
	return $recordingId;
}

function createVideoAndGetId($recordingId) {
	$sqlInsertNewVideo = "INSERT INTO video (recordings_id) VALUES (" . $recordingId . ");";
	mysql_query($sqlInsertNewVideo) or die("MySQL-Error: " . mysql_error());
	$videoId = mysql_insert_id();
	return $videoId;
}

function createAudioAndGetId($recordingId) {
	$sqlInsertNewAudio = "INSERT INTO audio (recordings_id) VALUES (" . $recordingId . ");";
	mysql_query($sqlInsertNewAudio) or die("MySQL-Error: " . mysql_error());
	$audioId = mysql_insert_id();
	return $audioId;
}

function insertConcertAndGetId($id_artist, $c_date, $id_country, $id_city, $id_venue, $c_supplement, $miscBoolean) {
	$sqlInsertNewConcert = "INSERT INTO concerts (artists_id,date,misc) VALUES (" . $id_artist . ",'" . $c_date . "'," . $miscBoolean . ");";
	mysql_query($sqlInsertNewConcert) or die("MySQL-Error: " . mysql_error());
	$concertId = mysql_insert_id();
	if (!empty ($id_country))
		mysql_query($sqlInsertCountry = "UPDATE concerts SET countrys_id=" . $id_country . " WHERE concerts.id=" . $concertId) or die("MySQL-Error: " . mysql_error());
	if (!empty ($id_city))
		mysql_query($sqlInsertCountry = "UPDATE concerts SET citys_id=" . $id_city . " WHERE concerts.id=" . $concertId) or die("MySQL-Error: " . mysql_error());
	if (!empty ($id_venue))
		mysql_query($sqlInsertCountry = "UPDATE concerts SET venues_id=" . $id_venue . " WHERE concerts.id=" . $concertId) or die("MySQL-Error: " . mysql_error());
	if (!empty ($c_supplement))
		mysql_query($sqlInsertCountry = "UPDATE concerts SET supplement='" . $c_supplement . "' WHERE concerts.id=" . $concertId) or die("MySQL-Error: " . mysql_error());
	return $concertId;
}

function changeConcertIdInRecord($recordId,$newConcertId) {
	$sql = "UPDATE recordings SET concerts_id =  $newConcertId  WHERE id=$recordId;";
	mysql_query($sql) or die(mysql_error());
	echo "altes record $recordId an neus concert $newConcertId gehangen";
}
?>
