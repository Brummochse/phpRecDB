<?php
function getArtistId($c_artist) {
	$sqlSelectQuery = "SELECT id FROM artists WHERE name='" . $c_artist . "'";
	$sqlInsertQuery = "INSERT INTO artists (name) VALUES ('" . $c_artist . "');";
	return getId($sqlSelectQuery, $sqlInsertQuery, $c_artist);
}

function getCountryId($c_country) {
	$sqlSelectQuery = "SELECT id FROM countrys WHERE name='" . $c_country . "'";
	$sqlInsertQuery = "INSERT INTO countrys (name) VALUES ('" . $c_country . "');";
	return getId($sqlSelectQuery, $sqlInsertQuery, $c_country);
}

function getCityId($c_city, $id_country) {
	if (empty ($id_country)) { //kein land angegeben aber eine stadt ist bekannt
		$sqlSelectQuery = "SELECT id FROM citys WHERE name='" . $c_city . "' AND countrys_id is null";
		$sqlInsertQuery = "INSERT INTO citys (name) VALUES ('" . $c_city . "');";
	} else {
		$sqlSelectQuery = "SELECT id FROM citys WHERE name='" . $c_city . "' AND countrys_id=" . $id_country;
		$sqlInsertQuery = "INSERT INTO citys (name,countrys_id) VALUES ('" . $c_city . "'," . $id_country . ");";
	}
	return getId($sqlSelectQuery, $sqlInsertQuery, $c_city);
}

function getVenueId($c_venue, $id_city) {
	if (empty ($id_city)) { //keine stadt angegeben aber eine venue ist bekannt
		$sqlSelectQuery = "SELECT id FROM venues WHERE name='" . $c_venue . "' AND citys_id is null";
		$sqlInsertQuery = "INSERT INTO venues (name) VALUES ('" . $c_venue . "');";
	} else {
		$sqlSelectQuery = "SELECT id FROM venues WHERE name='" . $c_venue . "' AND citys_id=" . $id_city;
		$sqlInsertQuery = "INSERT INTO venues (name,citys_id) VALUES ('" . $c_venue . "'," . $id_city . ");";
	}
	return getId($sqlSelectQuery, $sqlInsertQuery, $c_venue);
}

function getId($sqlSelectQuery, $sqlInsertQuery, $value) {
	if (strlen($value) == 0)
		return null;
	$queryResults = mysql_query($sqlSelectQuery) or die("MySQL-Error: " . mysql_error());
	$firstRow = mysql_fetch_row($queryResults);
	if (!empty ($firstRow)) {
		return $firstRow[0];
	} else {
		mysql_query($sqlInsertQuery) or die("MySQL-Error: " . mysql_error());
		return getId($sqlSelectQuery, $sqlInsertQuery, $value);
	}
}
?>
