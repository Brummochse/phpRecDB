<?php
include_once "../constants.php";
include_once Constants::getSettingsFolder() . "dbConnection.php";
include_once "functions/screenshotDb.php";
include_once Constants::getFunctionsFolder() . "function.getConcertInfo.php";
include_once Constants::getLibsFolder() . 'Smarty/Smarty.class.php';
include_once (Constants::getFunctionsFolder() . "function.getScreenshotsData.php");
include_once (Constants::getClassFolder() . "Linky.php");
include_once (Constants::getClassFolder() . "ScreenshotUploader.php");

dbConnect();

//$_GET['id'] = 247;
if (isset ($_GET['id'])) {
	$recordingId = (int) $_GET['id'];

	if (isset ($_POST['recordingId'])) {
		$uploader = new ScreenshotUploader();
		$uploader->uploadFile("screenshot");
		
		$recordingId = trim($_POST['recordingId']);
		addNewScreenshot($recordingId, $uploader->getNewImagefilename(), $uploader->getNewThumbnailFilename());
	}
	if (isset ($_GET['screenshotId']) && isset ($_GET['action']) && (!isset ($_POST['recordingId']))) {
		if ($_GET['action'] == "1") {
			deleteScreenshot($_GET['screenshotId'], "../screenshots/");
		}
		if ($_GET['action'] == "2") {
			orderBackward($_GET['screenshotId']);
		}
		if ($_GET['action'] == "3") {
			orderForward($_GET['screenshotId']);
		}

	}
	$smarty = new Smarty;
	$smarty->template_dir = Constants::getTemplateFolder();
	$smarty->compile_dir = Constants::getCompileFolder();

	getScreenshotsData($recordingId, "../screenshots/", $smarty, true);
	getConcertInfo($recordingId, true, $smarty);

	$linky = new Linky("lid");
	$smarty->assign('editRecordLink', $linky->encryptName('edit Record', array (
		'id' => $recordingId
	)));

	$smarty->assign('recordingId', $recordingId);
	$smarty->assign("relativeTemplatesPath", getRelativePathTo(Constants::getTemplateFolder()));
	$smarty->display("screenshots.tpl");
}
?>

