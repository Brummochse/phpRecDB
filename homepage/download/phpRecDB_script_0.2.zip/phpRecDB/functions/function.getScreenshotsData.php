<?php
include_once dirname(__FILE__) . "/../constants.php";
include_once Constants::getClassFolder()."Linky.php";

function getScreenshotsData($recordingId, $screenshotFolder, $smarty, $withLinks = false) {
	$result = mysql_query("SELECT * FROM `screenshot` WHERE video_recordings_id='$recordingId' ORDER BY order_id") or trigger_error(mysql_error());
	$screenshots = array ();
	$linky=new Linky("lid");
	while ($row = mysql_fetch_array($result)) {
		foreach ($row AS $key => $value) {
			$row[$key] = stripslashes($value);
		}
		$screenshot = array (
			'screenshot_filename' => $screenshotFolder . $row['screenshot_filename'],
			'thumbnail' => $screenshotFolder . $row['thumbnail'],
			'recordingId' => $recordingId,
			'id' => $row['id'],
			'deleteLink' => $linky->encryptName('screenshots',
			array (
				'screenshotId' => $row['id'],
				'id' => $recordingId,
				'action' => 1
			)
		), 'backwardLink' => $linky->encryptName('screenshots', array (
			'screenshotId' => $row['id'],
			'id' => $recordingId,
			'action' => 2
		)), 'forwardLink' => $linky->encryptName('screenshots', array (
			'screenshotId' => $row['id'],
			'id' => $recordingId,
			'action' => 3
		)),);
		array_push($screenshots, $screenshot);
	}
	$smarty->assign('screenshots', $screenshots);
}
?>
