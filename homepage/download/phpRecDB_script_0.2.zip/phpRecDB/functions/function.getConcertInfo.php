<?php

function getConcertInfo($recordingId, $withSourceIdentification, $smarty) {
	$sqlSelect = "SELECT artists.name, concerts.date, countrys.name, citys.name, venues.name, concerts.supplement, concerts.misc,recordings.sourceidentification " .
	"FROM concerts " .
	"LEFT OUTER JOIN artists ON artists.id = concerts.artists_id " .
	"LEFT OUTER JOIN countrys ON countrys.id = concerts.countrys_id " .
	"LEFT OUTER JOIN citys ON citys.id = concerts.citys_id " .
	"LEFT OUTER JOIN venues ON venues.id = concerts.venues_id " .
	"LEFT OUTER JOIN recordings ON concerts.id = recordings.concerts_id " .
	"WHERE recordings.id=" . $recordingId;
	$concertInfoResult = mysql_query($sqlSelect) or die("MySQL-Error: " . mysql_error());
	$concertInfo = mysql_fetch_row($concertInfoResult);

	$sourceIdentification = $concertInfo[7];
	$miscBoolean = $concertInfo[6];

	if (!$withSourceIdentification)
		$sourceIdentification = '';
	if ($miscBoolean == '1') {
		$misc = "(MISC)";
	} else {
		$misc = '';
	}

	$smarty->assign("artist", stripslashes($concertInfo[0]));
	$smarty->assign("date", $concertInfo[1]);
	$smarty->assign("country", stripslashes($concertInfo[2]));
	$smarty->assign("city", stripslashes($concertInfo[3]));
	$smarty->assign("venue", stripslashes($concertInfo[4]));
	$smarty->assign("supplement", stripslashes($concertInfo[5]));
	$smarty->assign("misc", $misc);
	if ($withSourceIdentification) {
		$smarty->assign("sourceidentification", $sourceIdentification);
	}
}
?>