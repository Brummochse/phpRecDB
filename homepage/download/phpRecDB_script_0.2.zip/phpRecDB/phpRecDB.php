<?php
class phpRecDB {

	public function printVideoList() {
		if ($this->showSelected() == false) {
			include_once "classes/InfoList.php";
			$list = new InfoList();
			$list->getList();
		}
	}
	
	public function printSelectionVideoList($filterName,$filterValue) {
		if ($this->showSelected() == false) {
			include_once "classes/InfoList.php";
			$list = new InfoList();
			$list->setFilter($filterName,$filterValue);
			$list->getList();
		}
	}
	
	public function printSelectionAudioList($filterName,$filterValue) {
		if ($this->showSelected() == false) {
			include_once "classes/AudioList.php";
			$list = new AudioList();	
			$list->setFilter($filterName,$filterValue);
			$list->getList();
		}
	}

	public function printVideoNews($newsCount = 5) {
		if ($this->showSelected() == false) {
			include_once "classes/VideoNewsList.php";
			$newsList = new VideoNewsList($newsCount);
			$newsList->getList();
		}
	}
	
	public function printAudioNews($newsCount = 5) {
		if ($this->showSelected() == false) {
			include_once "classes/AudioNewsList.php";
			$newsList = new AudioNewsList($newsCount);
			$newsList->getList();
		}
	}
	
	public function printVideoNewsEmbedded($newsCount = 5) {
		include_once "classes/EmbeddedVideoNews.php";
		$newsList = new EmbeddedVideoNews($newsCount);
		$newsList->getList();
	}
	
	public function printAudioNewsEmbedded($newsCount = 5) {
		include_once "classes/EmbeddedAudioNews.php";
		$newsList = new EmbeddedAudioNews($newsCount);
		$newsList->getList();
	}
	
	public function printAudioList() {
		if ($this->showSelected() == false) {
			include_once "classes/AudioList.php";
			$list = new AudioList();
			$list->getList();
		}
	}
	
	private function showSelected() {
		if (isset ($_GET['recId'])) {
			$recId = (int) $_GET['recId'];
			if (!empty ($recId)) {
				include_once "functions/function.getInfoPage.php";
				getInfoPage($recId);
				return true;
			}
		}
		return false;
	}

}
?>
