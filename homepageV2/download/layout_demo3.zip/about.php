<?php
include "templatefiles/header.php";
?>
<div id="content">
This is a demo website using following functions of the phpRecDB script:
<ul>
    <li>news-list</li>
    <li>video-list</li>
    <li>audio-list</li>
    <li>css customizing</li>
</ul>
<br>

</div>

<?php
include "templatefiles/footer.php";
?>
