<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<title>phpRecDB Demo Website</title>
<meta name="keywords" content="" />
<meta name="Gestured" content="" />
<link href="templatefiles/default.css" rel="stylesheet" type="text/css" media="screen" />
<link href="templatefiles/listOverwrite.css" rel="stylesheet" type="text/css" />
<link href="templatefiles/navBarOverwrite.css" rel="stylesheet" type="text/css" />
<link href="templatefiles/infoOverwrite.css" rel="stylesheet" type="text/css"/>

</head>
<body>
<div id="wrapper">
<!-- start header -->
<div id="header">
	<div id="menu">
		<ul >
			<li><a href="index.php">Home</a></li>
			<li><a href="news.php">News</a></li>
			<li><a href="videos.php">Videos</a></li>
                        <li><a href="audios.php">Audios</a></li>
			<li><a href="about.php">About</a></li>
		</ul>
	</div>
	<div id="logo">
		<h1>phpRecDB</h1>
		<p>Designed By Free CSS Templates</p>
	</div>
</div>
<!-- end header -->
	<!-- start page -->
	<div id="page">