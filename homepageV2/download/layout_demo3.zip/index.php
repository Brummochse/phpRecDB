<?php
include "templatefiles/header.php";
?>
<div id="content">
    <h1 >Demo Website</h1>
    You can manage your collection in the <a href="phpRecDB/index.php">administration area</a>.
</div>

<?php
include "templatefiles/footer.php";
?>
