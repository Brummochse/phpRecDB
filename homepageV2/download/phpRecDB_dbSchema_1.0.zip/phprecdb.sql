-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 27, 2013 at 02:52 PM
-- Server version: 5.6.11
-- PHP Version: 5.5.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `phprecdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `artists`
--

CREATE TABLE IF NOT EXISTS `artists` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `notes` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `aspectratio`
--

CREATE TABLE IF NOT EXISTS `aspectratio` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `label` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `aspectratio`
--

INSERT INTO `aspectratio` (`id`, `label`) VALUES
(1, '4:3'),
(2, '16:9');

-- --------------------------------------------------------

--
-- Table structure for table `audio`
--

CREATE TABLE IF NOT EXISTS `audio` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `recordings_id` int(11) NOT NULL,
  `bitrate` decimal(10,0) DEFAULT NULL,
  `frequence` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`id`,`recordings_id`),
  KEY `audio_FKIndex1` (`recordings_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `bootlegtypes`
--

CREATE TABLE IF NOT EXISTS `bootlegtypes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `label` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `bootlegtypes`
--

INSERT INTO `bootlegtypes` (`id`, `label`) VALUES
(1, 'video'),
(2, 'audio');

-- --------------------------------------------------------

--
-- Table structure for table `citys`
--

CREATE TABLE IF NOT EXISTS `citys` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `countrys_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `citys_FKIndex1` (`countrys_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `concerts`
--

CREATE TABLE IF NOT EXISTS `concerts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `artists_id` int(10) unsigned NOT NULL,
  `date` date NOT NULL,
  `countrys_id` int(10) unsigned DEFAULT NULL,
  `citys_id` int(10) unsigned DEFAULT NULL,
  `venues_id` int(10) unsigned DEFAULT NULL,
  `supplement` varchar(255) DEFAULT NULL,
  `misc` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `concerts_FKCountry` (`countrys_id`),
  KEY `concerts_FKCity` (`citys_id`),
  KEY `concerts_FKVenue` (`venues_id`),
  KEY `concerts_FKArtist` (`artists_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `countrys`
--

CREATE TABLE IF NOT EXISTS `countrys` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `dbmigration`
--

CREATE TABLE IF NOT EXISTS `dbmigration` (
  `version` varchar(255) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dbmigration`
--

INSERT INTO `dbmigration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1377607849),
('m130416_000001_phprecdb_0_2', 1377607852),
('m130416_000002_phprecdb_0_3', 1377607852),
('m130416_000003_phprecdb_0_4', 1377607852),
('m130416_000004_phprecdb_0_5', 1377607852),
('m130417_000000_phprecdb_1_0', 1377607855);

-- --------------------------------------------------------

--
-- Table structure for table `duration`
--

CREATE TABLE IF NOT EXISTS `duration` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `recordings_id` int(11) NOT NULL,
  `duration` decimal(10,0) DEFAULT NULL,
  `medianr` int(10) unsigned NOT NULL,
  `size` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `duration_FKIndex1` (`recordings_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `lists`
--

CREATE TABLE IF NOT EXISTS `lists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE IF NOT EXISTS `media` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bootlegtypes_id` int(10) unsigned NOT NULL,
  `label` varchar(255) DEFAULT NULL,
  `shortname` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `media_FKIndex1` (`bootlegtypes_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`id`, `bootlegtypes_id`, `label`, `shortname`) VALUES
(1, 1, 'DVD', 'DVD'),
(2, 1, 'BRD', 'Blue Ray Disc'),
(3, 2, 'CD', 'CD');

-- --------------------------------------------------------

--
-- Table structure for table `recordings`
--

CREATE TABLE IF NOT EXISTS `recordings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `concerts_id` int(10) unsigned NOT NULL,
  `sourceidentification` varchar(255) DEFAULT NULL,
  `rectypes_id` int(11) DEFAULT NULL,
  `sources_id` int(10) unsigned DEFAULT NULL,
  `media_id` int(10) unsigned DEFAULT NULL,
  `sumlength` decimal(8,2) DEFAULT NULL,
  `summedia` int(10) unsigned DEFAULT NULL,
  `quality` int(10) unsigned DEFAULT NULL,
  `setlist` mediumtext,
  `notes` mediumtext,
  `lastmodified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `sourcenotes` mediumtext,
  `taper` varchar(255) DEFAULT NULL,
  `transferer` varchar(255) DEFAULT NULL,
  `tradestatus_id` int(10) unsigned DEFAULT NULL,
  `visible` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `recordings_FKConcert` (`concerts_id`),
  KEY `recordings_FKIndex2` (`sources_id`),
  KEY `recordings_FKIndex3` (`rectypes_id`),
  KEY `recordings_FKIndex4` (`media_id`),
  KEY `recordings_FKIndex5` (`tradestatus_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `rectypes`
--

CREATE TABLE IF NOT EXISTS `rectypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bootlegtypes_id` int(10) unsigned NOT NULL,
  `label` varchar(255) DEFAULT NULL,
  `shortname` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rectypes_FKIndex1` (`bootlegtypes_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `rectypes`
--

INSERT INTO `rectypes` (`id`, `bootlegtypes_id`, `label`, `shortname`) VALUES
(1, 1, 'Audience', 'AUD'),
(2, 1, 'Professional', 'PRO'),
(3, 2, 'Audience', 'AUD'),
(4, 2, 'Soundboard', 'SBD');

-- --------------------------------------------------------

--
-- Table structure for table `screenshot`
--

CREATE TABLE IF NOT EXISTS `screenshot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `video_recordings_id` int(11) NOT NULL,
  `screenshot_filename` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `order_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `screenshots_FKIndex1` (`video_recordings_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `property` varchar(255) NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  UNIQUE KEY `property` (`property`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`property`, `value`) VALUES
('database_version', '1'),
('screenshot_compression', '1'),
('theme_name', 'default');

-- --------------------------------------------------------

--
-- Table structure for table `signature`
--

CREATE TABLE IF NOT EXISTS `signature` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  `additionalText` varchar(255) DEFAULT '',
  `bgTransparent` tinyint(1) DEFAULT '0',
  `bgColor` varchar(7) NOT NULL,
  `color1` varchar(7) NOT NULL,
  `color2` varchar(7) NOT NULL,
  `color3` varchar(7) NOT NULL,
  `quality` int(11) NOT NULL DEFAULT '9',
  `recordsCount` int(11) NOT NULL DEFAULT '5',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `sources`
--

CREATE TABLE IF NOT EXISTS `sources` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bootlegtypes_id` int(10) unsigned NOT NULL,
  `label` varchar(255) DEFAULT NULL,
  `shortname` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sources_FKIndex1` (`bootlegtypes_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `sources`
--

INSERT INTO `sources` (`id`, `bootlegtypes_id`, `label`, `shortname`) VALUES
(1, 1, 'VHS 1ST Generation', 'VHS 1'),
(2, 1, 'VHS 2ND Generation', 'VHS 2'),
(3, 1, 'VHS 3RD Generation', 'VHS 3'),
(4, 1, 'VHS Master', 'VHS M'),
(5, 1, 'Unspecified Master', 'M'),
(6, 1, 'MiniDV Master', 'M'),
(7, 1, 'HDD Master', 'M'),
(8, 1, 'DVD Master', 'M'),
(10, 1, 'VHS', 'VHS'),
(11, 1, 'VHS Low Generation', 'VHS LOW'),
(12, 1, 'VHS Mid Generation', 'VHS MID'),
(13, 1, 'VHS High Generation', 'VHS High'),
(14, 1, 'Digital Video Broadcast ', 'DVB'),
(15, 1, 'Hi8 Master', 'M'),
(16, 1, 'Digital8 Master', 'M'),
(17, 1, 'Standalone-Recorder-Copy From DVD(Master)', 'M'),
(23, 2, 'FLAC', 'FLAC'),
(24, 2, 'SHN', 'SHN'),
(25, 2, 'WAV', 'WAV');

-- --------------------------------------------------------

--
-- Table structure for table `sublists`
--

CREATE TABLE IF NOT EXISTS `sublists` (
  `recordings_id` int(11) NOT NULL,
  `lists_id` int(11) NOT NULL,
  UNIQUE KEY `recordings_id` (`recordings_id`,`lists_id`),
  KEY `fk_sublist_lists_id` (`lists_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tradestatus`
--

CREATE TABLE IF NOT EXISTS `tradestatus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `label` varchar(255) DEFAULT NULL,
  `shortname` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tradestatus`
--

INSERT INTO `tradestatus` (`id`, `label`, `shortname`) VALUES
(1, 'Rare Trades Only', 'RT'),
(2, 'Not For Trade', 'NFT');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `salt`, `role`) VALUES
(1, 'admin', '301c8f149458935864e0571c4a924d2d', '51326697797012.15232076', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `venues`
--

CREATE TABLE IF NOT EXISTS `venues` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `citys_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `notes` mediumtext,
  PRIMARY KEY (`id`),
  KEY `venues_FKIndex1` (`citys_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `video`
--

CREATE TABLE IF NOT EXISTS `video` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `recordings_id` int(11) NOT NULL,
  `aspectratio_id` int(10) unsigned DEFAULT NULL,
  `videoformat_id` int(10) unsigned DEFAULT NULL,
  `bitrate` decimal(10,0) DEFAULT NULL,
  `authorer` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`,`recordings_id`),
  KEY `video_FKIndex1` (`recordings_id`),
  KEY `video_FKIndex2` (`videoformat_id`),
  KEY `video_FKIndex3` (`aspectratio_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `videoformat`
--

CREATE TABLE IF NOT EXISTS `videoformat` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `label` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `videoformat`
--

INSERT INTO `videoformat` (`id`, `label`) VALUES
(1, 'PAL'),
(2, 'NTSC'),
(3, 'HDTV');

-- --------------------------------------------------------

--
-- Table structure for table `youtubesamples`
--

CREATE TABLE IF NOT EXISTS `youtubesamples` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `youtubeId` varchar(255) NOT NULL,
  `recordings_id` int(11) NOT NULL,
  `order_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_youtubesamples_recordings_id` (`recordings_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `audio`
--
ALTER TABLE `audio`
  ADD CONSTRAINT `audio_ibfk_1` FOREIGN KEY (`recordings_id`) REFERENCES `recordings` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `citys`
--
ALTER TABLE `citys`
  ADD CONSTRAINT `citys_ibfk_1` FOREIGN KEY (`countrys_id`) REFERENCES `countrys` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `concerts`
--
ALTER TABLE `concerts`
  ADD CONSTRAINT `concerts_ibfk_1` FOREIGN KEY (`countrys_id`) REFERENCES `countrys` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `concerts_ibfk_2` FOREIGN KEY (`citys_id`) REFERENCES `citys` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `concerts_ibfk_3` FOREIGN KEY (`venues_id`) REFERENCES `venues` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `concerts_ibfk_4` FOREIGN KEY (`artists_id`) REFERENCES `artists` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `duration`
--
ALTER TABLE `duration`
  ADD CONSTRAINT `duration_ibfk_1` FOREIGN KEY (`recordings_id`) REFERENCES `recordings` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `recordings`
--
ALTER TABLE `recordings`
  ADD CONSTRAINT `recordings_ibfk_1` FOREIGN KEY (`concerts_id`) REFERENCES `concerts` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `recordings_ibfk_2` FOREIGN KEY (`sources_id`) REFERENCES `sources` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `recordings_ibfk_3` FOREIGN KEY (`rectypes_id`) REFERENCES `rectypes` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `recordings_ibfk_4` FOREIGN KEY (`media_id`) REFERENCES `media` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `recordings_ibfk_5` FOREIGN KEY (`tradestatus_id`) REFERENCES `tradestatus` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `screenshot`
--
ALTER TABLE `screenshot`
  ADD CONSTRAINT `recordingFK1` FOREIGN KEY (`video_recordings_id`) REFERENCES `recordings` (`id`);

--
-- Constraints for table `sublists`
--
ALTER TABLE `sublists`
  ADD CONSTRAINT `fk_sublist_recordings_id` FOREIGN KEY (`recordings_id`) REFERENCES `recordings` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_sublist_lists_id` FOREIGN KEY (`lists_id`) REFERENCES `lists` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `venues`
--
ALTER TABLE `venues`
  ADD CONSTRAINT `venues_ibfk_1` FOREIGN KEY (`citys_id`) REFERENCES `citys` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `video`
--
ALTER TABLE `video`
  ADD CONSTRAINT `video_ibfk_1` FOREIGN KEY (`recordings_id`) REFERENCES `recordings` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `video_ibfk_2` FOREIGN KEY (`videoformat_id`) REFERENCES `videoformat` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `video_ibfk_3` FOREIGN KEY (`aspectratio_id`) REFERENCES `aspectratio` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `youtubesamples`
--
ALTER TABLE `youtubesamples`
  ADD CONSTRAINT `fk_youtubesamples_recordings_id` FOREIGN KEY (`recordings_id`) REFERENCES `recordings` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
