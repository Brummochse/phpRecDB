-- phpMyAdmin SQL Dump
-- version 2.11.9.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Erstellungszeit: 15. November 2009 um 22:50
-- Server Version: 5.0.67
-- PHP-Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `recdbDEMO`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `artists`
--

CREATE TABLE IF NOT EXISTS `artists` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `notes` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `artists`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `aspectratio`
--

CREATE TABLE IF NOT EXISTS `aspectratio` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `label` varchar(10) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Daten für Tabelle `aspectratio`
--

INSERT INTO `aspectratio` (`id`, `label`) VALUES
(1, '4:3'),
(2, '16:9');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `audio`
--

CREATE TABLE IF NOT EXISTS `audio` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `recordings_id` int(11) NOT NULL,
  `bitrate` decimal(10,0) default NULL,
  `frequence` decimal(10,0) default NULL,
  PRIMARY KEY  (`id`,`recordings_id`),
  KEY `audio_FKIndex1` (`recordings_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `audio`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `bootlegtypes`
--

CREATE TABLE IF NOT EXISTS `bootlegtypes` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `label` varchar(10) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Daten für Tabelle `bootlegtypes`
--

INSERT INTO `bootlegtypes` (`id`, `label`) VALUES
(1, 'video'),
(2, 'audio');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `citys`
--

CREATE TABLE IF NOT EXISTS `citys` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `countrys_id` int(10) unsigned default NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `citys_FKIndex1` (`countrys_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `citys`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `concerts`
--

CREATE TABLE IF NOT EXISTS `concerts` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `artists_id` int(10) unsigned NOT NULL,
  `date` date NOT NULL,
  `countrys_id` int(10) unsigned default NULL,
  `citys_id` int(10) unsigned default NULL,
  `venues_id` int(10) unsigned default NULL,
  `supplement` varchar(45) default NULL,
  `misc` tinyint(1) default NULL,
  PRIMARY KEY  (`id`),
  KEY `concerts_FKCountry` (`countrys_id`),
  KEY `concerts_FKCity` (`citys_id`),
  KEY `concerts_FKVenue` (`venues_id`),
  KEY `concerts_FKArtist` (`artists_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `concerts`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `countrys`
--

CREATE TABLE IF NOT EXISTS `countrys` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `countrys`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `duration`
--

CREATE TABLE IF NOT EXISTS `duration` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `recordings_id` int(11) NOT NULL,
  `duration` decimal(10,0) default NULL,
  `medianr` int(10) unsigned NOT NULL,
  `size` decimal(10,0) default NULL,
  PRIMARY KEY  (`id`),
  KEY `duration_FKIndex1` (`recordings_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `duration`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `media`
--

CREATE TABLE IF NOT EXISTS `media` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `bootlegtypes_id` int(10) unsigned NOT NULL,
  `label` varchar(20) NOT NULL,
  `shortname` varchar(20) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `media_FKIndex1` (`bootlegtypes_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Daten für Tabelle `media`
--

INSERT INTO `media` (`id`, `bootlegtypes_id`, `label`, `shortname`) VALUES
(1, 1, 'DVD', 'DVD'),
(2, 1, 'BRD', 'Blue Ray Disc'),
(3, 2, 'CD', 'CD');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `myuser`
--

CREATE TABLE IF NOT EXISTS `myuser` (
  `ID` int(10) unsigned NOT NULL auto_increment,
  `userName` char(50) character set latin1 collate latin1_bin default NULL,
  `userPass` char(50) character set latin1 collate latin1_bin default NULL,
  `isAdmin` tinyint(2) NOT NULL default '-1',
  `userGroup` int(10) unsigned default '1',
  `sessionID` char(50) default NULL,
  `lastLog` datetime default NULL,
  `userRemark` char(255) default NULL,
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `userName` (`userName`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='Created by the AdminPro Class MySQL Setup ' AUTO_INCREMENT=4 ;

--
-- Daten für Tabelle `myuser`
--

INSERT INTO `myuser` (`ID`, `userName`, `userPass`, `isAdmin`, `userGroup`, `sessionID`, `lastLog`, `userRemark`) VALUES
(3, 'admin', '5ebe2294ecd0e0f08eab7690d2a6ee69', 1, 1, '', '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `recordings`
--

CREATE TABLE IF NOT EXISTS `recordings` (
  `id` int(11) NOT NULL auto_increment,
  `concerts_id` int(10) unsigned NOT NULL,
  `sourceidentification` varchar(50) default NULL,
  `rectypes_id` int(11) default NULL,
  `sources_id` int(10) unsigned default NULL,
  `media_id` int(10) unsigned default NULL,
  `sumlength` decimal(10,0) default NULL,
  `summedia` int(10) unsigned default NULL,
  `quality` int(10) unsigned default NULL,
  `setlist` text,
  `notes` text,
  `lastmodified` date default NULL,
  `created` date default NULL,
  `sourcenotes` text,
  `taper` varchar(50) default NULL,
  `transferer` varchar(50) default NULL,
  `tradestatus_id` int(10) unsigned default NULL,
  PRIMARY KEY  (`id`),
  KEY `recordings_FKConcert` (`concerts_id`),
  KEY `recordings_FKIndex2` (`sources_id`),
  KEY `recordings_FKIndex3` (`rectypes_id`),
  KEY `recordings_FKIndex4` (`media_id`),
  KEY `recordings_FKIndex5` (`tradestatus_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `recordings`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `rectypes`
--

CREATE TABLE IF NOT EXISTS `rectypes` (
  `id` int(11) NOT NULL auto_increment,
  `bootlegtypes_id` int(10) unsigned NOT NULL,
  `label` varchar(45) NOT NULL,
  `shortname` varchar(3) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `rectypes_FKIndex1` (`bootlegtypes_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Daten für Tabelle `rectypes`
--

INSERT INTO `rectypes` (`id`, `bootlegtypes_id`, `label`, `shortname`) VALUES
(1, 1, 'Audience', 'AUD'),
(2, 1, 'Professional', 'PRO'),
(3, 2, 'Audience', 'AUD'),
(4, 2, 'Soundboard', 'SBD');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `screenshot`
--

CREATE TABLE IF NOT EXISTS `screenshot` (
  `id` int(11) NOT NULL auto_increment,
  `video_recordings_id` int(11) NOT NULL,
  `screenshot_filename` varchar(255) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `video_id` int(10) unsigned default NULL,
  `order_id` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `screenshots_FKIndex1` (`video_id`,`video_recordings_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `screenshot`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `sources`
--

CREATE TABLE IF NOT EXISTS `sources` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `bootlegtypes_id` int(10) unsigned NOT NULL,
  `label` varchar(45) NOT NULL,
  `shortname` varchar(10) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `sources_FKIndex1` (`bootlegtypes_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Daten für Tabelle `sources`
--

INSERT INTO `sources` (`id`, `bootlegtypes_id`, `label`, `shortname`) VALUES
(1, 1, 'VHS 1ST Generation', 'VHS 1'),
(2, 1, 'VHS 2ND Generation', 'VHS 2'),
(3, 1, 'VHS 3RD Generation', 'VHS 3'),
(4, 1, 'VHS Master', 'VHS M'),
(5, 1, 'Unspecified Master', 'M'),
(6, 1, 'MiniDV Master', 'M'),
(7, 1, 'HDD Master', 'M'),
(8, 1, 'DVD Master', 'M'),
(10, 1, 'VHS', 'VHS'),
(11, 1, 'VHS Low Generation', 'VHS LOW'),
(12, 1, 'VHS Mid Generation', 'VHS MID'),
(13, 1, 'VHS High Generation', 'VHS High'),
(14, 1, 'Digital Video Broadcast ', 'DVB'),
(15, 1, 'Hi8 Master', 'M'),
(16, 1, 'Digital8 Master', 'M'),
(17, 1, 'Standalone-Recorder-Copy From DVD(Master)', 'M'),
(23, 2, 'FLAC', 'FLAC'),
(24, 2, 'SHN', 'SHN'),
(25, 2, 'WAV', 'WAV');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tradestatus`
--

CREATE TABLE IF NOT EXISTS `tradestatus` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `label` varchar(50) NOT NULL,
  `shortname` varchar(3) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Daten für Tabelle `tradestatus`
--

INSERT INTO `tradestatus` (`id`, `label`, `shortname`) VALUES
(1, 'Rare Trades Only', 'RT'),
(2, 'Not For Trade', 'NFT');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `venues`
--

CREATE TABLE IF NOT EXISTS `venues` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `citys_id` int(10) unsigned default NULL,
  `name` varchar(255) NOT NULL,
  `notes` text,
  PRIMARY KEY  (`id`),
  KEY `venues_FKIndex1` (`citys_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `venues`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `video`
--

CREATE TABLE IF NOT EXISTS `video` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `recordings_id` int(11) NOT NULL,
  `aspectratio_id` int(10) unsigned default NULL,
  `videoformat_id` int(10) unsigned default NULL,
  `bitrate` decimal(10,0) default NULL,
  `authorer` varchar(50) default NULL,
  PRIMARY KEY  (`id`,`recordings_id`),
  KEY `video_FKIndex1` (`recordings_id`),
  KEY `video_FKIndex2` (`videoformat_id`),
  KEY `video_FKIndex3` (`aspectratio_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Daten für Tabelle `video`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `videoformat`
--

CREATE TABLE IF NOT EXISTS `videoformat` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `label` varchar(4) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Daten für Tabelle `videoformat`
--

INSERT INTO `videoformat` (`id`, `label`) VALUES
(1, 'PAL'),
(2, 'NTSC'),
(3, 'HDTV');

--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `audio`
--
ALTER TABLE `audio`
  ADD CONSTRAINT `audio_ibfk_1` FOREIGN KEY (`recordings_id`) REFERENCES `recordings` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints der Tabelle `citys`
--
ALTER TABLE `citys`
  ADD CONSTRAINT `citys_ibfk_1` FOREIGN KEY (`countrys_id`) REFERENCES `countrys` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints der Tabelle `concerts`
--
ALTER TABLE `concerts`
  ADD CONSTRAINT `concerts_ibfk_1` FOREIGN KEY (`countrys_id`) REFERENCES `countrys` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `concerts_ibfk_2` FOREIGN KEY (`citys_id`) REFERENCES `citys` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `concerts_ibfk_3` FOREIGN KEY (`venues_id`) REFERENCES `venues` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `concerts_ibfk_4` FOREIGN KEY (`artists_id`) REFERENCES `artists` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints der Tabelle `duration`
--
ALTER TABLE `duration`
  ADD CONSTRAINT `duration_ibfk_1` FOREIGN KEY (`recordings_id`) REFERENCES `recordings` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints der Tabelle `recordings`
--
ALTER TABLE `recordings`
  ADD CONSTRAINT `recordings_ibfk_1` FOREIGN KEY (`concerts_id`) REFERENCES `concerts` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `recordings_ibfk_2` FOREIGN KEY (`sources_id`) REFERENCES `sources` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `recordings_ibfk_3` FOREIGN KEY (`rectypes_id`) REFERENCES `rectypes` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `recordings_ibfk_4` FOREIGN KEY (`media_id`) REFERENCES `media` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `recordings_ibfk_5` FOREIGN KEY (`tradestatus_id`) REFERENCES `tradestatus` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints der Tabelle `screenshot`
--
ALTER TABLE `screenshot`
  ADD CONSTRAINT `screenshot_ibfk_1` FOREIGN KEY (`video_id`, `video_recordings_id`) REFERENCES `video` (`id`, `recordings_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints der Tabelle `venues`
--
ALTER TABLE `venues`
  ADD CONSTRAINT `venues_ibfk_1` FOREIGN KEY (`citys_id`) REFERENCES `citys` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints der Tabelle `video`
--
ALTER TABLE `video`
  ADD CONSTRAINT `video_ibfk_1` FOREIGN KEY (`recordings_id`) REFERENCES `recordings` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `video_ibfk_2` FOREIGN KEY (`videoformat_id`) REFERENCES `videoformat` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `video_ibfk_3` FOREIGN KEY (`aspectratio_id`) REFERENCES `aspectratio` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
