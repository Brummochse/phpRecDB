<html>
	<head>
  		<title>phpRecDB Demo</title>
  	</head>
  	<body>
		<center>
			<h1>phpRecDB Demo</h1>
			<a href="index.php">Home</a>
			<a href="video.php">Videos</a>
			<a href="audio.php">Audios</a>
			<br><hr><br>
			
			<?php
				include_once "phpRecDB/phpRecDB.php";
				$list=new phpRecDB();
				$list->printAudioNews(10);
			?>
			
		</center>
	</body>
</html>