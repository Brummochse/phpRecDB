<?php
$sites=array (
		'Add Record' => 'addRecordingWizard.php',
		'Manage Video List' => 'AdminVideoList.php',
		'Manage Audio List' => 'AdminAudioList.php',
		'aspectratio' => 'cruds/aspectratio.php',
		'media' => 'cruds/media.php',
		'rectypes' => 'cruds/rectypes.php',
		'sources' => 'cruds/sources.php',
		'tradestatus' => 'cruds/tradestatus.php',
		'videoformat' => 'cruds/videoformat.php',
		
		'User Management'=> 'user/adminuser.php',
		
		'Add Concert'=>'addConcert.php',
		'edit Concert'=>'editConcert.php',
		'edit Record'=>'editRecord.php',
		'delete Record'=>'deleteRecord.php',
		'screenshots'=>'screenshots.php'
);

$menuStructure = array (
	'Records' => array (
		$sites['Add Record'],
		$sites['Manage Video List'],
		$sites['Manage Audio List']
	),
	'Configuration' => array (
		$sites['User Management'],
		$sites['aspectratio'],
		$sites['media'],
		$sites['rectypes'],
		$sites['sources'],
		$sites['tradestatus'],
		$sites['videoformat']
	)
);
?>

