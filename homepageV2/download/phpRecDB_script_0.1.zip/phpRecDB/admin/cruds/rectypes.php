<link rel="stylesheet" type="text/css" href="cruds/style.css" />
<?
$table="rectypes";
include "bootlegtypesBased.php"
?>
