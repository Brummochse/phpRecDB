<link rel="stylesheet" type="text/css" href="cruds/style.css" />
<?
$table="aspectratio";
include dirname(__FILE__) . '/../../constants.php';
include $libsFolder."Crud/simpleCrudSelect.php";
?>
