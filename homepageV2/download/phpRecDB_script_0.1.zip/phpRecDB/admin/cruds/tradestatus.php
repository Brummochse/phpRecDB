<link rel="stylesheet" type="text/css" href="cruds/style.css" />
<?
$table="tradestatus";
include dirname(__FILE__) . '/../../constants.php';
include $libsFolder."Crud/simpleCrudSelect.php";
?>
