<?php
include_once "../constants.php";
include_once ('../libs/Smarty/Smarty.class.php');

$smarty = new Smarty;
$smarty->template_dir = $templateFolder;
$smarty->compile_dir = $compileFolder;

$smarty->assign('addConcertLink', 'editConcert.php');
$smarty->assign('audioOrVideoSelection', 'true');
$smarty->assign("relativeTemplatesPath", getRelativePathTo($templateFolder));
$smarty->display("editConcert.tpl");
?>