<?php
include_once "../settings/dbConnection.php";
dbConnect();

if (isset ($_GET['id'])) {
	$recordingId = (int) $_GET['id'];

	$sqlSelect = "SELECT artists.name, concerts.date, countrys.name, citys.name, venues.name, concerts.supplement, concerts.misc,concerts.id " .
	"FROM concerts " .
	"LEFT OUTER JOIN artists ON artists.id = concerts.artists_id " .
	"LEFT OUTER JOIN countrys ON countrys.id = concerts.countrys_id " .
	"LEFT OUTER JOIN citys ON citys.id = concerts.citys_id " .
	"LEFT OUTER JOIN venues ON venues.id = concerts.venues_id " .
	"LEFT OUTER JOIN recordings ON concerts.id = recordings.concerts_id " .
	"WHERE recordings.id=" . $recordingId;
	$result = mysql_query($sqlSelect) or die("MySQL-Error: " . mysql_error());
	$concert = mysql_fetch_row($result);

	$artist = $concert[0];
	$date = $concert[1];
	$country = stripslashes($concert[2]);
	$city = stripslashes($concert[3]);
	$venue = stripslashes($concert[4]);
	$supplement = stripslashes($concert[5]);
	$misc = $concert[6];
	$concertId = $concert[7];

	include "../constants.php";
	include_once ('../libs/Smarty/Smarty.class.php');
	include_once ($classFolder."Linky.php");

	$smarty = new Smarty;
	$smarty->template_dir = $templateFolder;
	$smarty->compile_dir = $compileFolder;
	
	///////////counting records which belong to this show
	$sqlSelect = "SELECT id FROM `recordings` WHERE concerts_id=" . $concertId;
	mysql_query($sqlSelect) or die("MySQL-Error: " . mysql_error());
	$recordsCount = mysql_affected_rows();

	if ($recordsCount > 1) {
		$smarty->assign('recordsPerShowCount', $recordsCount);
	}
	///////////

	$linky=new Linky("lid");
	$smarty->assign('editRecordLink', $linky->encryptName('edit Record',array('id'=>$recordingId)));

	$smarty->assign('recordingId', $recordingId);

	$smarty->assign('artist', $artist);
	$smarty->assign('date', $date);
	$smarty->assign('country', $country);
	$smarty->assign('city', $city);
	$smarty->assign('venue', $venue);
	$smarty->assign('supplement', $supplement);
	$smarty->assign('concertId', $concertId);
	$smarty->assign('audioOrVideoSelection', 'false');
	if ($misc == '1') {
		$smarty->assign('misc', 'true');
	}
	$smarty->assign("relativeTemplatesPath", getRelativePathTo($templateFolder));
	$smarty->display("editConcert.tpl");

}

function evaluateMisc($c_misc) {
	if (empty ($c_misc)) {
		return 0;
	} else {
		return 1;
	}
}
?>
