<?php
session_start();

include_once "../constants.php";
include_once $libsFolder."SimpleMember/adminpro_class.php";
$prot = new protect("0", "1");
if ($prot->showPage) {
	$curUser = $prot->getUser();

	include "menu.php";
	
	echo ("You are logged in as: <b>" . $curUser) . "</b>";

	$lid = (int) $_GET['lid'];

	include "sitemap.php";
	$linky = new Linky();

	$link = $linky->decrypt($lid);
	if (!empty ($link)) {
		include $link;
	} else {
		include $adminFolder."about.php";
	}
}
?>
