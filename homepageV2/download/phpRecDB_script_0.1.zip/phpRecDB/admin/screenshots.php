<?php
include_once "../constants.php";
include_once $settingsFolder."dbConnection.php";
include_once "functions/screenshotDb.php";
include_once $functionsFolder."function.getConcertInfo.php";
include_once $libsFolder.'Smarty/Smarty.class.php';
include_once ($functionsFolder."function.getScreenshotsData.php");
include_once ($classFolder."Linky.php");
dbConnect();

//$_GET['id'] = 247;
if (isset ($_GET['id'])) {
	$recordingId = (int) $_GET['id'];

	if (isset ($_POST['recordingId'])) {
		include "functions/screenshotUpload.php";
	}
	if (isset ($_GET['screenshotId']) && isset ($_GET['action']) && (!isset ($_POST['recordingId']))) {
		if ($_GET['action'] == "1") {
			deleteScreenshot($_GET['screenshotId'], "../screenshots/");
		}
		if ($_GET['action'] == "2") {
			orderBackward($_GET['screenshotId']);
		}
		if ($_GET['action'] == "3") {
			orderForward($_GET['screenshotId']);
		}

	}
	$smarty = new Smarty;
	$smarty->template_dir = $templateFolder;
	$smarty->compile_dir = $compileFolder;

	getScreenshotsData($recordingId, "../screenshots/", $smarty,true);
	getConcertInfo($recordingId, true, $smarty);
	
	$linky=new Linky("lid");
	$smarty->assign('editRecordLink', $linky->encryptName('edit Record',array('id'=>$recordingId)));
	
	$smarty->assign('recordingId', $recordingId);
	$smarty->assign("relativeTemplatesPath", getRelativePathTo($templateFolder));
	$smarty->display("screenshots.tpl");
}

?>

