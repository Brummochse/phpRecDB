<?php
function uploadImage($fileName, $recordingId) {
	$maxSize = 99999999999;
	$maxW = 250;
	$fullPath = '../screenshots/';
	$relPath = $fullPath;

	$folder = $relPath;
	$maxlimit = $maxSize;
	$allowed_ext = "jpg,jpeg,gif,png,bmp";
	$match = "";
	$filesize = $_FILES[$fileName]['size'];
	if ($filesize > 0) {
		$filename = strtolower($_FILES[$fileName]['name']);
		$filename = preg_replace('/\s/', '_', $filename);
		if ($filesize < 1) {
			$errorList[] = "File size is empty.";
		}
		if ($filesize > $maxlimit) {
			$errorList[] = "File size is too big.";
		}
		if (count($errorList) < 1) {
			$file_ext = preg_split("/\./", $filename);
			$allowed_ext = preg_split("/\,/", $allowed_ext);
			foreach ($allowed_ext as $ext) {
				if ($ext == end($file_ext)) {
					$match = "1"; // File is allowed
					$NUM = time();
					$front_name = substr($file_ext[0], 0, 15);
					$newImagefilename = $front_name . "_" . $NUM . "." . end($file_ext);
					$newThumbnailFilename = "thumb_" . $newImagefilename;
					$filetype = end($file_ext);
					$imageSave = $folder . $newImagefilename;
					$thumbnailSave = $folder . $newThumbnailFilename;
					if ((!file_exists($imageSave)) && (!file_exists($thumbnailSave))) {

						list ($width_orig, $height_orig) = getimagesize($_FILES[$fileName]['tmp_name']);

						if ($width_orig < $maxW) {
							$fwidth = $width_orig;
						} else {
							$fwidth = $maxW;
						}
						$ratio_orig = $width_orig / $height_orig;
						$fheight = $fwidth / $ratio_orig;

						$blank_height = $fheight;
						$top_offset = 0;

						$image_p = imagecreatetruecolor($fwidth, $blank_height);
						$white = imagecolorallocate($image_p, 255, 255, 255);
						imagefill($image_p, 0, 0, $white);
						switch ($filetype) {
							case "gif" :
								$image = @ imagecreatefromgif($_FILES[$fileName]['tmp_name']);
								break;
							case "jpg" :
								$image = @ imagecreatefromjpeg($_FILES[$fileName]['tmp_name']);
								break;
							case "jpeg" :
								$image = @ imagecreatefromjpeg($_FILES[$fileName]['tmp_name']);
								break;
							case "png" :
								$image = @ imagecreatefrompng($_FILES[$fileName]['tmp_name']);
								break;
						}
						@ imagecopyresampled($image_p, $image, 0, $top_offset, 0, 0, $fwidth, $fheight, $width_orig, $height_orig);
						switch ($filetype) {
							case "gif" :
								if (!@ imagegif($image_p, $thumbnailSave)) {
									$errorList[] = "PERMISSION DENIED [GIF]";
								}
								break;
							case "jpg" :
								if (!@ imagejpeg($image_p, $thumbnailSave, 70)) {
									$errorList[] = "PERMISSION DENIED [JPG]";
								}
								break;
							case "jpeg" :
								if (!@ imagejpeg($image_p, $thumbnailSave, 70)) {
									$errorList[] = "PERMISSION DENIED [JPEG]";
								}
								break;
							case "png" :
								if (!@ imagepng($image_p, $thumbnailSave, 0)) {
									$errorList[] = "PERMISSION DENIED [PNG]";
								}
								break;
						}
						if (!move_uploaded_file($_FILES[$fileName]['tmp_name'], $imageSave)) {
							$errorList[] = "error moving";
						}
						@ imagedestroy($filename);
					} else {
						$errorList[] = "CANNOT MAKE IMAGE IT ALREADY EXISTS";
					}
				}
			}
		}
	} else {
		$errorList[] = "NO FILE SELECTED";
	}
	if (!$match) {
		$errorList[] = "File type isn't allowed: $filename";
	}

	//in db einf�gen
	addNewScreenshot($recordingId, $newImagefilename, $newThumbnailFilename);

	//

	if (sizeof($errorList) == 0) {
		return "succes";
	} else {
		$eMessage = array ();
		for ($x = 0; $x < sizeof($errorList); $x++) {
			$eMessage[] = $errorList[$x];
		}
		return $eMessage;
	}
}

$recordingId = trim($_POST['recordingId']);
$filename = "screenshot";

$upload_image = uploadImage($filename, $recordingId);
if (is_array($upload_image)) {
	foreach ($upload_image as $key => $value) {
		if ($value == "-ERROR-") {
			unset ($upload_image[$key]);
		}
	}
	$document = array_values($upload_image);
	for ($x = 0; $x < sizeof($document); $x++) {
		$errorList[] = $document[$x];
	}
	$imgUploaded = false;
} else {
	$imgUploaded = true;
}

if ($imgUploaded) {
	echo "upload successfull!";
} else {
	echo 'Error(s) Found: ';
	foreach ($errorList as $value) {
		echo $value . ', ';
	}
}
?>