<?php
include_once ('../libs/Smarty/Smarty.class.php');
include dirname(__FILE__) . "/../constants.php";
include_once ($classFolder.'Linky.php');

$smarty = new Smarty;
$smarty->template_dir = $templateFolder;
$smarty->compile_dir = $compileFolder;

include "sitemap.php";
$linky=new Linky("lid");
$indexSite="index.php";

$chapters = array ();
foreach ($menuStructure as $chapterName => $menuPoint) {
	$sections = array ();
	if (is_array($menuPoint)) {
		foreach ($menuPoint as $link) {
			$section = array (
				'name' => $linky->getNameForLink($link),
				'link' => $indexSite.$linky->encryptLink($link)
			);
			array_push($sections, $section);
		}

	}
	$chapter = array (
		'name' => $chapterName,
		'sections' => $sections
	);
	array_push($chapters, $chapter);
}
$logout = array (
		'name' => 'logout',
		'link' => $indexSite.'?action=logout'
);
array_push($chapters, $logout);


$smarty->assign('chapters', $chapters);

$smarty->display('menu.tpl');

?>
