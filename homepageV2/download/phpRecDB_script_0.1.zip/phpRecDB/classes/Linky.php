<?php
class Linky {

	private $paramName;
	//index=>link
	private $decryptList = array ();
	//link=>index
	private $encryptList = array ();
	
	//link=>name
	private $linkList = array ();
	
	private $sites;
	
	private $counter = 0;

	function Linky($paramName='') {
		include dirname(__FILE__) . "/../admin/sitemap.php";
		$this->paramName=$paramName;
		$this->sites=$sites;
		$this->createCryptLists();		
	}

	function createCryptLists() {
		foreach ($this->sites as $key => $value) {
			$this->counter++;
//			echo "<br>$key => $value      $this->counter"; 
			$this->decryptList[$this->counter] = $value;
			$this->encryptList[$value] = $this->counter;
			$this->linkList[$value] = $key;
		}
	}

	function createLink($id,$params) {
		$paramStr='';
		if (is_array($params)) {
			foreach ($params as $paramName => $paramValue) {
				$paramStr=$paramStr."&".$paramName."=".$paramValue;
			}
		}
		return "?".$this->paramName."=".$id.$paramStr;
	}
	public function encryptLink($link,$params=null) {
		$id= $this->encryptList[$link];
		return $this->createLink($id,$params);
	}
	public function encryptName($name,$params=null) {
		$id=  $this->encryptList[$this->sites[$name]];
		return $this->createLink($id,$params);
	}
	
	public function getNameForLink($link)  {
		return $this->linkList[$link];
	}

	public function decrypt($index) {
		return $this->decryptList[$index];
	}
}
//$test=new Linky();
?>
