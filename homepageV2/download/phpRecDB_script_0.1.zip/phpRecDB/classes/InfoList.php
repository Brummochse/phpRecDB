<?php
include_once "ListBuilder.php";

class InfoList extends ListBuilder {
		
	function InfoList() {
		parent:: ListBuilder();
	}
	
	function getInfoLink($recordingId) {
		$url = $this->makeUrl(array (
			'recId' => $recordingId
		));
		$link = "<a href='$url'>info</a>";
		return $link;
	}

	function getButtons($recordingId) {
		return $this->getInfoLink($recordingId);
	}
}
?>
