 <?php
include_once "AudioNewsList.php";

class EmbeddedAudioNews extends AudioNewsList {
	
	function getArtistLink($artistId) {
		return "#";
	}
	
	function EmbeddedAudioNews($newsCount) {
		parent :: AudioNewsList($newsCount);
		$this->setSignatureVisibility(false);
	}
	
	function getButtons($recordingId) {
		return "";
	}
	
}

?>
