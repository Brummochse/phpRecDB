 <?php
include_once "VideoNewsList.php";

class EmbeddedVideoNews extends VideoNewsList {
	
	function getArtistLink($artistId) {
		return "#";
	}
	
	function EmbeddedVideoNews($newsCount) {
		parent :: VideoNewsList($newsCount);
		$this->setSignatureVisibility(false);
	}
	
	function getButtons($recordingId) {
		return "";
	}
	
}

?>
