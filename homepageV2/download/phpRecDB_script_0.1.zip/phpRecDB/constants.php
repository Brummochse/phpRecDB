<?php
$templateFolder=dirname(__FILE__)."/templates/";
$compileFolder=dirname(__FILE__)."/templates_c/";
$functionsFolder=dirname(__FILE__)."/functions/";
$classFolder=dirname(__FILE__)."/classes/";
$libsFolder=dirname(__FILE__)."/libs/";
$mainFolder==dirname(__FILE__)."/";
$screenshotsFolder=dirname(__FILE__)."/screenshots/";
$settingsFolder=dirname(__FILE__)."/settings/";
$adminFolder=dirname(__FILE__)."/admin/";

?>