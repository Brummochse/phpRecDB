<?php

return array(
    'screenshotsUrl' => $phpRecDbUrl .(empty($phpRecDbUrl)?'':'/'). 'screenshots',
    'version' => '1.0',
    'wwwUrl' => $phpRecDbUrl .(empty($phpRecDbUrl)?'':'/') . 'app/www'
);