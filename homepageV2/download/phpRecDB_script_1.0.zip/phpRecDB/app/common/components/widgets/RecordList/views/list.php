<?php

$this->widget('CPrdGridViewCore', array(
    'id' => $id,
    'dataProvider' => $listDataProvider,
    'columns' => $listColumns,
));
?>