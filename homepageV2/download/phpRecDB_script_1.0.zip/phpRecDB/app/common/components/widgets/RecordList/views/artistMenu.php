<?php
    $this->widget('MbMenu', array(
        'items'=>$items,
        'cssFile' => Yii::app()->params['wwwUrl'] . '/css/mbmenu_blue/mbmenu.css',
    ));
?>
