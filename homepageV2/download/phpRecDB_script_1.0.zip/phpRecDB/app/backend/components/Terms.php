<?php

class Terms {

    const SCREENSHOT = 'Screenshots';
    const YOUTUBE = 'Youtube';
    const INFORMATION = 'Record_Inormation';
    const SUBLISTS = 'Sublists';
    
    const BEFORE = 1;
    const BEHIND = 2;
    
    const CHECKBOX_ID = "checkbox_id";
    
    const SUBLIST_ID = "sublist_id";

}

?>
