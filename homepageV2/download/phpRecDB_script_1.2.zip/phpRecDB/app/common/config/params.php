<?php

return array(
    'screenshotsUrl' => $phpRecDbUrl .(empty($phpRecDbUrl)?'':'/'). 'screenshots',
    'version' => '1.2',
    'wwwUrl' => $phpRecDbUrl .(empty($phpRecDbUrl)?'':'/') . 'app/www',
    'artistMenuMaxChunkSize'=>20
);