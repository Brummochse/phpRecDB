<?php

class FileInfo {

    public $dir = '';
    public $fileNameBase = '';
    public $fileExtension = '';
}

?>
