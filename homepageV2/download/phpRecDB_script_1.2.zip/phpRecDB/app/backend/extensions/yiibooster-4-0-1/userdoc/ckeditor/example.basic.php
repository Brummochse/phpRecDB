<?php // Basic usage of TbCKEditor widget
$this->widget(
    'booster.widgets.TbCKEditor',
    array(
        'name' => 'some_text_field'
    )
);
