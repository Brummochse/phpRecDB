<p>
    <?php
    $this->widget('booster.widgets.TbLabel', array('label' => 'counted visits:',));
    echo " " .$visitCounter;
    ?>
</p>