<?php
echo $form->textFieldGroup($vaModel, 'bitrate', array( 'widgetOptions'=>array ('htmlOptions'=>array('maxlength' => 10))));
echo $form->textFieldGroup($vaModel, 'frequence', array( 'widgetOptions'=>array ('htmlOptions'=>array('maxlength' => 10))));