<?php

class AllListDataConfig extends CollapsableListDataConfig {

    public function __construct($collapsed = true, $isAdminCall = false) {
        parent::__construct($collapsed, $isAdminCall);
    }

}

?>
