<object width="192" height="152">
    <param name="movie" value="<?= $youtubeUrl ?>" />
    <param name="allowFullScreen" value="true" />
    <param name="allowscriptaccess" value="always" />
    <embed src="<?= $youtubeUrl ?>" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="192" height="152"></embed>
</object>