<p>
    <?php
    $this->widget('bootstrap.widgets.TbLabel', array('label' => 'counted visits:',));
    echo " " .$visitCounter;
    ?>
</p>